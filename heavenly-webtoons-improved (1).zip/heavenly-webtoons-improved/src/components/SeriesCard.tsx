import { Link } from "@tanstack/react-router";
import { Star, MessageSquare, Sparkles } from "lucide-react";
import { useState, useEffect } from "react";
import type { Series } from "@/lib/series";
import { getReviewStats } from "@/components/ReviewSection";

export function SeriesCard({ s }: { s: Series }) {
  const [communityRating, setCommunityRating] = useState<number | null>(null);
  const [reviewCount, setReviewCount] = useState(0);

  useEffect(() => {
    const stats = getReviewStats(s.slug);
    if (stats.count > 0) { setCommunityRating(stats.average); setReviewCount(stats.count); }
  }, [s.slug]);

  const displayRating = communityRating ?? s.rating;
  const statusColor = s.status === "Ongoing" ? "text-emerald-400" : s.status === "Completed" ? "text-blue-400" : "text-amber-400";

  return (
    <Link to="/series/$slug" params={{ slug: s.slug }}
      className="group relative overflow-hidden rounded-xl bg-card shadow-[var(--shadow-card)] transition-all duration-300 hover:-translate-y-1.5 hover:shadow-[var(--shadow-glow)]">
      <div className="aspect-[2/3] overflow-hidden bg-muted">
        <img src={s.cover} alt={s.title} loading="lazy" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110" />
      </div>

      {/* Type badge */}
      <div className="absolute top-2 left-2 rounded-md bg-background/80 backdrop-blur px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-primary">
        {s.type}
      </div>

      {/* NEW badge */}
      {s.isNew && (
        <div className="absolute top-8 left-2 flex items-center gap-0.5 rounded-md bg-[image:var(--gradient-hero)] px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-white shadow-[var(--shadow-glow)]">
          <Sparkles className="h-2.5 w-2.5" /> Nouveau
        </div>
      )}

      {/* Rating */}
      {displayRating != null && (
        <div className="absolute top-2 right-2 flex items-center gap-1 rounded-md bg-background/80 backdrop-blur px-2 py-0.5 text-xs font-semibold">
          <Star className="h-3 w-3 fill-primary text-primary" />
          {displayRating.toFixed(1)}
          {reviewCount > 0 && (
            <span className="text-muted-foreground text-[10px] flex items-center gap-0.5 ml-0.5">
              <MessageSquare className="h-2.5 w-2.5" />{reviewCount}
            </span>
          )}
        </div>
      )}

      {/* Info overlay */}
      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-background via-background/90 to-transparent p-3 pt-10">
        <h3 className="line-clamp-2 text-sm font-bold leading-tight">{s.title}</h3>
        <div className="mt-1 flex items-center justify-between">
          {s.chapters[0] ? (
            <p className="text-xs text-muted-foreground">Ch. {s.chapters[0].number}</p>
          ) : <span />}
          <span className={`text-[10px] font-bold ${statusColor}`}>
            {s.status === "Ongoing" ? "En cours" : s.status === "Completed" ? "Terminé" : "Pause"}
          </span>
        </div>
      </div>
    </Link>
  );
}
