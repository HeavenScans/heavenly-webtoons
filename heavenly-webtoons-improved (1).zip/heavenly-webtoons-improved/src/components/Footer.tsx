import { Link } from "@tanstack/react-router";
import { BookOpen, MessageCircle, Twitter, Github, Heart, Crown } from "lucide-react";

type AppRoute = "/" | "/series" | "/genres" | "/latest" | "/premium";

const NAV_LINKS: { to: AppRoute; label: string }[] = [
  { to: "/", label: "Accueil" },
  { to: "/series", label: "Séries" },
  { to: "/genres", label: "Genres" },
  { to: "/latest", label: "Derniers chapitres" },
  { to: "/premium", label: "Premium" },
];

const INFO_LINKS = [
  { label: "À propos", href: "#" },
  { label: "Discord", href: "https://discord.gg/" },
  { label: "Contact", href: "mailto:contact@heavenscans.fr" },
  { label: "DMCA / Signalement", href: "#" },
  { label: "CGU", href: "#" },
];

export function Footer() {
  return (
    <footer className="mt-24 border-t border-border bg-card/40">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-12 grid gap-10 md:grid-cols-4">
        {/* Brand */}
        <div className="md:col-span-2">
          <div className="flex items-center gap-2">
            <div className="grid h-9 w-9 place-items-center rounded-lg bg-[image:var(--gradient-hero)] shadow-[var(--shadow-glow)]">
              <BookOpen className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-black">Heaven<span className="text-primary">Scans</span></span>
          </div>
          <p className="mt-4 max-w-md text-sm text-muted-foreground">
            Votre paradis pour lire les meilleurs mangas, manhwas, manhuas et webtoons traduits par une équipe passionnée. Nouvelles sorties chaque semaine.
          </p>

          <Link to="/premium" className="mt-5 inline-flex items-center gap-2 rounded-xl border border-[color:var(--glass-border)] bg-[color:var(--glass-bg)] backdrop-blur px-4 py-2 text-sm font-bold text-[color:var(--neon-blue)] hover:border-[color:var(--neon-blue)] hover:shadow-[var(--shadow-neon-violet)] transition-all">
            <Crown className="h-4 w-4" /> Devenir Premium
          </Link>

          <div className="mt-5 flex gap-3">
            <a href="https://twitter.com/" target="_blank" rel="noopener noreferrer" aria-label="Twitter"
              className="grid h-9 w-9 place-items-center rounded-lg bg-secondary hover:bg-muted hover:text-primary transition-colors">
              <Twitter className="h-4 w-4" />
            </a>
            <a href="https://discord.gg/" target="_blank" rel="noopener noreferrer" aria-label="Discord"
              className="grid h-9 w-9 place-items-center rounded-lg bg-secondary hover:bg-muted hover:text-primary transition-colors">
              <MessageCircle className="h-4 w-4" />
            </a>
            <a href="https://github.com/" target="_blank" rel="noopener noreferrer" aria-label="GitHub"
              className="grid h-9 w-9 place-items-center rounded-lg bg-secondary hover:bg-muted hover:text-primary transition-colors">
              <Github className="h-4 w-4" />
            </a>
          </div>
        </div>

        {/* Navigation */}
        <div>
          <h4 className="text-sm font-bold uppercase tracking-wider">Navigation</h4>
          <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
            {NAV_LINKS.map(({ to, label }) => (
              <li key={to}>
                <Link to={to} className="hover:text-primary transition-colors">{label}</Link>
              </li>
            ))}
          </ul>
        </div>

        {/* Infos */}
        <div>
          <h4 className="text-sm font-bold uppercase tracking-wider">Infos</h4>
          <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
            {INFO_LINKS.map(({ label, href }) => (
              <li key={label}>
                <a href={href} className="hover:text-foreground transition-colors">{label}</a>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="border-t border-border py-5 text-center text-xs text-muted-foreground flex flex-wrap items-center justify-center gap-1">
        <span>© {new Date().getFullYear()} HeavenScans — Tous droits réservés.</span>
        <span className="flex items-center gap-1 ml-1">Fait avec <Heart className="h-3 w-3 fill-primary text-primary" /> par la team HeavenScans.</span>
      </div>
    </footer>
  );
}
