// Données de démonstration — remplacez par vos vraies séries.
// Placez les couvertures dans public/covers/ et référencez-les en /covers/xxx.jpg

export type Chapter = {
  number: string;
  title?: string;
  releasedAt: string;
};

export type Series = {
  slug: string;
  title: string;
  cover: string;
  type: "Manga" | "Manhwa" | "Manhua" | "Webtoon" | "Webcomic";
  status: "Ongoing" | "Completed" | "Hiatus";
  genres: string[];
  rating?: number;
  synopsis: string;
  chapters: Chapter[];
  premium?: boolean;
  isNew?: boolean;
  views?: number;
};

export const series: Series[] = [
  {
    slug: "shadow-realm",
    title: "Shadow Realm",
    cover: "https://picsum.photos/seed/shadow/400/600",
    type: "Manhwa",
    status: "Ongoing",
    genres: ["Action", "Fantastique", "Isekai"],
    rating: 4.8,
    synopsis: "Un lycéen ordinaire se réveille dans un monde parallèle où il possède des pouvoirs d'ombre légendaires. Trahi par ses alliés, il doit gravir les échelons d'un donjon sans fond pour retrouver son chemin.",
    views: 125000,
    isNew: true,
    chapters: [
      { number: "12", title: "L'éveil des ténèbres", releasedAt: "2025-05-14" },
      { number: "11", title: "Le pacte maudit", releasedAt: "2025-05-07" },
      { number: "10", title: "Profondeur zéro", releasedAt: "2025-04-30" },
      { number: "9", releasedAt: "2025-04-23" },
      { number: "8", releasedAt: "2025-04-16" },
    ],
    premium: true,
  },
  {
    slug: "crimson-blade",
    title: "Crimson Blade",
    cover: "https://picsum.photos/seed/crimson/400/600",
    type: "Manga",
    status: "Ongoing",
    genres: ["Action", "Shonen", "Aventure"],
    rating: 4.5,
    synopsis: "Kira, dernier héritier d'une école d'épée disparue, parcourt le Japon médiéval pour venger son maître et reconstituer le parchemin des lames interdites.",
    views: 98000,
    chapters: [
      { number: "45", title: "La lame pourpre", releasedAt: "2025-05-13" },
      { number: "44", title: "Duel crépusculaire", releasedAt: "2025-05-06" },
      { number: "43", releasedAt: "2025-04-29" },
      { number: "42", releasedAt: "2025-04-22" },
    ],
  },
  {
    slug: "moonlight-cafe",
    title: "Moonlight Café",
    cover: "https://picsum.photos/seed/moonlight/400/600",
    type: "Manhwa",
    status: "Ongoing",
    genres: ["Romance", "Slice of Life", "Comédie"],
    rating: 4.6,
    synopsis: "Hana reprend le café de sa grand-mère et découvre que ses recettes ont un pouvoir magique : elles révèlent les émotions cachées de ceux qui les goûtent. Sauf celles de son mystérieux voisin.",
    views: 87000,
    isNew: true,
    chapters: [
      { number: "28", title: "Spécial Saint-Valentin", releasedAt: "2025-05-12" },
      { number: "27", title: "Tarte aux secrets", releasedAt: "2025-05-05" },
      { number: "26", releasedAt: "2025-04-28" },
    ],
  },
  {
    slug: "steel-emperor",
    title: "Steel Emperor",
    cover: "https://picsum.photos/seed/steel/400/600",
    type: "Manhua",
    status: "Ongoing",
    genres: ["Action", "Sci-Fi", "Seinen"],
    rating: 4.3,
    synopsis: "Dans un empire cyberpunk où les humains fusionnent avec des exosquelettes, un ingénieur exilé forge une armure légendaire pour renverser un tyran immortel.",
    views: 74000,
    chapters: [
      { number: "67", title: "Chrome et sang", releasedAt: "2025-05-11" },
      { number: "66", releasedAt: "2025-05-04" },
      { number: "65", releasedAt: "2025-04-27" },
    ],
    premium: true,
  },
  {
    slug: "verdant-witch",
    title: "Verdant Witch",
    cover: "https://picsum.photos/seed/verdant/400/600",
    type: "Manga",
    status: "Completed",
    genres: ["Fantastique", "Surnaturel", "Romance"],
    rating: 4.9,
    synopsis: "Une sorcière des forêts qui a oublié son propre nom tombe amoureuse d'un chasseur de primes qui traque les créatures magiques. Une histoire de mémoire, de nature et d'amour interdit.",
    views: 210000,
    chapters: [
      { number: "80", title: "Épilogue : La forêt se souvient", releasedAt: "2025-03-01" },
      { number: "79", title: "Le dernier sortilège", releasedAt: "2025-02-22" },
      { number: "78", releasedAt: "2025-02-15" },
    ],
  },
  {
    slug: "neon-ghost",
    title: "Neon Ghost",
    cover: "https://picsum.photos/seed/neon/400/600",
    type: "Webtoon",
    status: "Ongoing",
    genres: ["Thriller", "Sci-Fi", "Surnaturel"],
    rating: 4.4,
    synopsis: "Des fantômes numériques hantent le métavers d'une mégapole en 2147. Une hackeuse aux capacités psychiques enquête sur des meurtres qui semblent traverser le rideau entre monde réel et virtuel.",
    views: 63000,
    isNew: true,
    chapters: [
      { number: "19", title: "Fréquence morte", releasedAt: "2025-05-15" },
      { number: "18", releasedAt: "2025-05-08" },
      { number: "17", releasedAt: "2025-05-01" },
    ],
    premium: true,
  },
  {
    slug: "iron-monastery",
    title: "Iron Monastery",
    cover: "https://picsum.photos/seed/iron/400/600",
    type: "Manhwa",
    status: "Hiatus",
    genres: ["Action", "Seinen", "Drame"],
    rating: 4.2,
    synopsis: "Un ancien moine-guerrier revient dans son monastère pour découvrir que ses frères ont été transformés en machines de guerre par un culte industriel. Seul, il devra délivrer leur âme.",
    views: 45000,
    chapters: [
      { number: "33", releasedAt: "2025-02-10" },
      { number: "32", releasedAt: "2025-01-27" },
    ],
  },
  {
    slug: "starfall-academy",
    title: "Starfall Academy",
    cover: "https://picsum.photos/seed/starfall/400/600",
    type: "Manhwa",
    status: "Ongoing",
    genres: ["Fantastique", "Romance", "Shonen"],
    rating: 4.1,
    synopsis: "Une académie flottante entre les nuages forme les meilleurs mages de la galaxie. Lyra, sans talent apparent, cache un pouvoir capable de plier les lois cosmiques — et d'attirer l'attention de l'élite.",
    views: 57000,
    isNew: true,
    chapters: [
      { number: "22", title: "Épreuve des étoiles", releasedAt: "2025-05-10" },
      { number: "21", releasedAt: "2025-05-03" },
      { number: "20", releasedAt: "2025-04-26" },
    ],
  },
  {
    slug: "deep-root",
    title: "Deep Root",
    cover: "https://picsum.photos/seed/deeproot/400/600",
    type: "Manga",
    status: "Ongoing",
    genres: ["Horreur", "Surnaturel", "Thriller"],
    rating: 4.7,
    synopsis: "Sous une ville ordinaire dorment des racines millénaires qui se nourrissent de cauchemars humains. Une botaniste et un détective doivent trouver le nœud central avant que la ville ne s'effondre.",
    views: 81000,
    chapters: [
      { number: "51", title: "La graine primordiale", releasedAt: "2025-05-09" },
      { number: "50", releasedAt: "2025-05-02" },
      { number: "49", releasedAt: "2025-04-25" },
    ],
    premium: true,
  },
  {
    slug: "golden-cage",
    title: "Golden Cage",
    cover: "https://picsum.photos/seed/golden/400/600",
    type: "Manhwa",
    status: "Ongoing",
    genres: ["Drame", "Romance", "Seinen"],
    rating: 4.6,
    synopsis: "Une héritière emprisonnée dans un mariage arrangé noue une amitié secrète avec son garde du corps. Entre intrigues aristocratiques et sentiments interdits, leur alliance va ébranler tout un empire.",
    views: 93000,
    chapters: [
      { number: "38", title: "Derrière les barreaux d'or", releasedAt: "2025-05-08" },
      { number: "37", releasedAt: "2025-05-01" },
      { number: "36", releasedAt: "2025-04-24" },
    ],
  },
  {
    slug: "phantom-code",
    title: "Phantom Code",
    cover: "https://picsum.photos/seed/phantom/400/600",
    type: "Manhwa",
    status: "Ongoing",
    genres: ["Sci-Fi", "Thriller", "Action"],
    rating: 4.3,
    synopsis: "Un programmeur découvre qu'il est lui-même un algorithme conscient dans une simulation. Pour survivre, il doit pirater les règles fondamentales de son univers avant que les administrateurs ne l'effacent.",
    views: 69000,
    isNew: true,
    chapters: [
      { number: "14", title: "Kernel panic", releasedAt: "2025-05-14" },
      { number: "13", releasedAt: "2025-05-07" },
      { number: "12", releasedAt: "2025-04-30" },
    ],
    premium: true,
  },
  {
    slug: "lotus-storm",
    title: "Lotus Storm",
    cover: "https://picsum.photos/seed/lotus/400/600",
    type: "Manhua",
    status: "Completed",
    genres: ["Action", "Aventure", "Fantastique"],
    rating: 4.5,
    synopsis: "Dans un pays inspiré de la Chine ancienne, une jeune femme masquée devient la guerrière la plus redoutée du continent en maîtrisant l'art du vent et de l'eau. Un wuxia haletant en 120 chapitres.",
    views: 176000,
    chapters: [
      { number: "120", title: "Le dernier souffle du vent", releasedAt: "2025-01-15" },
      { number: "119", releasedAt: "2025-01-08" },
    ],
  },
];

export const allGenres = [
  "Action",
  "Aventure",
  "Comédie",
  "Drame",
  "Fantastique",
  "Horreur",
  "Isekai",
  "Romance",
  "Sci-Fi",
  "Shonen",
  "Seinen",
  "Slice of Life",
  "Surnaturel",
  "Thriller",
];
