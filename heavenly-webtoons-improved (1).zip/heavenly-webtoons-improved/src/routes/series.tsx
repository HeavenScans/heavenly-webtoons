import { createFileRoute } from "@tanstack/react-router";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { SeriesCard } from "@/components/SeriesCard";
import { EmptyState } from "@/components/EmptyState";
import { series } from "@/lib/series";
import { useState, useMemo } from "react";
import { SlidersHorizontal, X } from "lucide-react";

export const Route = createFileRoute("/series")({
  head: () => ({
    meta: [
      { title: "Séries — HeavenScans" },
      { name: "description", content: "Catalogue complet des mangas, manhwas et webtoons traduits par HeavenScans." },
    ],
  }),
  component: SeriesPage,
});

const TYPES = ["Tous", "Manga", "Manhwa", "Manhua", "Webtoon"] as const;
const STATUSES = ["Tous", "En cours", "Terminé", "En pause"] as const;
const STATUS_MAP: Record<string, string> = { "En cours": "Ongoing", "Terminé": "Completed", "En pause": "Hiatus" };
const SORTS = ["A–Z", "Z–A", "Note", "Plus récent"] as const;

function SeriesPage() {
  const [typeFilter, setTypeFilter] = useState("Tous");
  const [statusFilter, setStatusFilter] = useState("Tous");
  const [sort, setSort] = useState<typeof SORTS[number]>("Plus récent");
  const [showFilters, setShowFilters] = useState(false);

  const filtered = useMemo(() => {
    let list = [...series];
    if (typeFilter !== "Tous") list = list.filter((s) => s.type === typeFilter);
    if (statusFilter !== "Tous") list = list.filter((s) => s.status === STATUS_MAP[statusFilter]);
    switch (sort) {
      case "A–Z": list.sort((a, b) => a.title.localeCompare(b.title)); break;
      case "Z–A": list.sort((a, b) => b.title.localeCompare(a.title)); break;
      case "Note": list.sort((a, b) => (b.rating ?? 0) - (a.rating ?? 0)); break;
      case "Plus récent": list.sort((a, b) => {
        const da = a.chapters[0]?.releasedAt ?? ""; const db = b.chapters[0]?.releasedAt ?? "";
        return db.localeCompare(da);
      }); break;
    }
    return list;
  }, [typeFilter, statusFilter, sort]);

  const hasFilters = typeFilter !== "Tous" || statusFilter !== "Tous";

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="mx-auto w-full max-w-7xl flex-1 px-4 sm:px-6 py-12">
        {/* Header */}
        <div className="flex flex-wrap items-end justify-between gap-4 mb-6">
          <div>
            <p className="text-sm font-semibold uppercase tracking-wider text-primary">Bibliothèque</p>
            <h1 className="mt-1 text-4xl font-black">Toutes les séries</h1>
            <p className="mt-1 text-muted-foreground">{filtered.length} série{filtered.length > 1 ? "s" : ""}</p>
          </div>
          <button onClick={() => setShowFilters((v) => !v)}
            className={`inline-flex items-center gap-2 rounded-xl border px-4 py-2 text-sm font-semibold transition-all ${showFilters ? "border-primary bg-primary/10 text-primary" : "border-border hover:border-primary/50"}`}>
            <SlidersHorizontal className="h-4 w-4" /> Filtres {hasFilters && <span className="h-2 w-2 rounded-full bg-primary" />}
          </button>
        </div>

        {/* Filters panel */}
        {showFilters && (
          <div className="mb-6 rounded-2xl border border-[color:var(--glass-border)] bg-[color:var(--glass-bg)] backdrop-blur-xl p-5 space-y-4">
            <div className="grid sm:grid-cols-3 gap-4">
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2 block">Type</label>
                <div className="flex flex-wrap gap-2">
                  {TYPES.map((t) => (
                    <button key={t} onClick={() => setTypeFilter(t)}
                      className={`rounded-full border px-3 py-1 text-xs font-semibold transition-all ${typeFilter === t ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:border-primary/50"}`}>
                      {t}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2 block">Statut</label>
                <div className="flex flex-wrap gap-2">
                  {STATUSES.map((s) => (
                    <button key={s} onClick={() => setStatusFilter(s)}
                      className={`rounded-full border px-3 py-1 text-xs font-semibold transition-all ${statusFilter === s ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:border-primary/50"}`}>
                      {s}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2 block">Trier par</label>
                <div className="flex flex-wrap gap-2">
                  {SORTS.map((s) => (
                    <button key={s} onClick={() => setSort(s)}
                      className={`rounded-full border px-3 py-1 text-xs font-semibold transition-all ${sort === s ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:border-primary/50"}`}>
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            {hasFilters && (
              <button onClick={() => { setTypeFilter("Tous"); setStatusFilter("Tous"); }}
                className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors">
                <X className="h-3.5 w-3.5" /> Réinitialiser les filtres
              </button>
            )}
          </div>
        )}

        {/* Grid */}
        {filtered.length === 0 ? (
          <EmptyState title="Aucune série trouvée" hint="Modifie les filtres pour voir plus de séries." />
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {filtered.map((s) => <SeriesCard key={s.slug} s={s} />)}
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}
