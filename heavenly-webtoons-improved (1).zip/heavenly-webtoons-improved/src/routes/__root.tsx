import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import appCss from "../styles.css?url";
import { BookOpen, RotateCcw, Home, AlertTriangle } from "lucide-react";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <div className="mx-auto grid h-20 w-20 place-items-center rounded-3xl bg-[image:var(--gradient-hero)] shadow-[var(--shadow-glow)]">
          <BookOpen className="h-9 w-9 text-white" />
        </div>
        <h1 className="mt-6 text-8xl font-black bg-[image:var(--gradient-hero)] bg-clip-text text-transparent">404</h1>
        <h2 className="mt-2 text-xl font-bold">Page introuvable</h2>
        <p className="mt-2 text-sm text-muted-foreground">Cette page n'existe pas ou a été déplacée.</p>
        <Link to="/" className="mt-6 inline-flex items-center gap-2 rounded-xl bg-[image:var(--gradient-hero)] px-5 py-2.5 text-sm font-bold text-white shadow-[var(--shadow-glow)] hover:scale-[1.02] transition">
          <Home className="h-4 w-4" /> Retour à l'accueil
        </Link>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl border border-destructive/30 bg-destructive/10">
          <AlertTriangle className="h-7 w-7 text-destructive" />
        </div>
        <h1 className="mt-5 text-xl font-bold">Une erreur est survenue</h1>
        <p className="mt-2 text-sm text-muted-foreground">Quelque chose s'est mal passé. Essaie de recharger la page.</p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button onClick={() => { router.invalidate(); reset(); }}
            className="inline-flex items-center gap-2 rounded-xl bg-[image:var(--gradient-hero)] px-4 py-2.5 text-sm font-bold text-white shadow-[var(--shadow-glow)] hover:scale-[1.02] transition">
            <RotateCcw className="h-4 w-4" /> Réessayer
          </button>
          <Link to="/" className="inline-flex items-center gap-2 rounded-xl border border-border bg-background px-4 py-2.5 text-sm font-bold hover:bg-muted transition">
            <Home className="h-4 w-4" /> Accueil
          </Link>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "HeavenScans — Mangas, Manhwas & Webtoons en VF" },
      { name: "description", content: "Lisez les derniers chapitres de mangas, manhwas et webtoons traduits par HeavenScans." },
      { name: "author", content: "HeavenScans" },
      { property: "og:title", content: "HeavenScans" },
      { property: "og:description", content: "HeavenScans — Mangas, Manhwas et Webtoons en VF." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "twitter:site", content: "@HeavenScans" },
    ],
    links: [{ rel: "stylesheet", href: appCss }],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <head><HeadContent /></head>
      <body>{children}<Scripts /></body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <Outlet />
    </QueryClientProvider>
  );
}
