import { useState, useEffect, useRef } from "react";
import { Star, MessageSquare, Trash2, ThumbsUp, Send, ChevronDown, ChevronUp } from "lucide-react";

export type Review = {
  id: string;
  author: string;
  rating: number;
  content: string;
  date: string;
  likes: number;
  likedByMe: boolean;
};

export type ReviewStats = {
  average: number;
  count: number;
  distribution: number[];
};

const storageKey = (slug: string) => `heavenscans:reviews:${slug}`;

export function getReviewStats(slug: string): ReviewStats {
  const reviews = loadReviews(slug);
  if (reviews.length === 0) return { average: 0, count: 0, distribution: [0, 0, 0, 0, 0] };
  const dist = [5, 4, 3, 2, 1].map((star) => reviews.filter((r) => r.rating === star).length);
  const avg = reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length;
  return { average: Math.round(avg * 10) / 10, count: reviews.length, distribution: dist };
}

function loadReviews(slug: string): Review[] {
  try {
    const raw = localStorage.getItem(storageKey(slug));
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

function saveReviews(slug: string, reviews: Review[]) {
  try { localStorage.setItem(storageKey(slug), JSON.stringify(reviews)); } catch {}
}

const AVATAR_COLORS = [
  "oklch(0.55 0.20 295)", "oklch(0.75 0.18 240)", "oklch(0.78 0.16 75)",
  "oklch(0.62 0.24 25)", "oklch(0.70 0.18 160)", "oklch(0.68 0.22 330)",
];
function pickColor(name: string): string {
  let h = 0;
  for (const c of name) h = (h * 31 + c.charCodeAt(0)) & 0xffffffff;
  return AVATAR_COLORS[Math.abs(h) % AVATAR_COLORS.length];
}

function StarPicker({ value, onChange, size = 24, readonly = false }: { value: number; onChange?: (v: number) => void; size?: number; readonly?: boolean }) {
  const [hovered, setHovered] = useState(0);
  const display = readonly ? value : hovered || value;
  return (
    <div className="flex items-center gap-0.5" onMouseLeave={() => !readonly && setHovered(0)}>
      {[1,2,3,4,5].map((star) => (
        <button key={star} type="button" disabled={readonly} onClick={() => !readonly && onChange?.(star)} onMouseEnter={() => !readonly && setHovered(star)} style={{ cursor: readonly ? "default" : "pointer" }}>
          <Star style={{ width: size, height: size }} className={`transition-colors duration-100 ${star <= display ? "fill-[oklch(0.78_0.16_75)] text-[oklch(0.78_0.16_75)]" : "fill-transparent text-[oklch(0.35_0.03_270)]"}`} />
        </button>
      ))}
    </div>
  );
}

function RatingBar({ label, count, total }: { label: string; count: number; total: number }) {
  const pct = total === 0 ? 0 : Math.round((count / total) * 100);
  return (
    <div className="flex items-center gap-2 text-xs">
      <span className="w-4 text-right text-muted-foreground font-medium">{label}</span>
      <Star className="h-3 w-3 fill-[oklch(0.78_0.16_75)] text-[oklch(0.78_0.16_75)] flex-shrink-0" />
      <div className="flex-1 h-1.5 rounded-full bg-[oklch(0.26_0.03_270)] overflow-hidden">
        <div className="h-full rounded-full bg-[image:var(--gradient-hero)] transition-all duration-700" style={{ width: `${pct}%` }} />
      </div>
      <span className="w-6 text-muted-foreground">{count}</span>
    </div>
  );
}

function ReviewCard({ review, onDelete, onLike, isOwn }: { review: Review; onDelete: () => void; onLike: () => void; isOwn: boolean }) {
  const initials = review.author.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase();
  return (
    <div className="group rounded-2xl border border-[color:var(--glass-border)] bg-[color:var(--glass-bg)] backdrop-blur-xl p-4 sm:p-5 transition-all hover:border-[color:var(--neon-blue)]/30">
      <div className="flex items-start gap-3">
        <div className="grid h-9 w-9 flex-shrink-0 place-items-center rounded-xl text-xs font-black text-white shadow-lg" style={{ background: pickColor(review.author) }}>
          {initials}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm">{review.author}</span>
              {isOwn && <span className="rounded-full border border-[color:var(--glass-border)] bg-[color:var(--glass-bg)] px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-[color:var(--neon-blue)]">Moi</span>}
            </div>
            <div className="flex items-center gap-2">
              <StarPicker value={review.rating} size={13} readonly />
              <span className="text-xs text-muted-foreground">{review.date}</span>
              {isOwn && (
                <button onClick={onDelete} className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive" aria-label="Supprimer">
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          </div>
          <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{review.content}</p>
          <button onClick={onLike} className={`mt-3 inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-xs font-semibold transition-all ${review.likedByMe ? "border-[color:var(--neon-blue)]/40 bg-[color:var(--neon-blue)]/10 text-[color:var(--neon-blue)]" : "border-border text-muted-foreground hover:border-[color:var(--neon-blue)]/30 hover:text-foreground"}`}>
            <ThumbsUp className="h-3 w-3" />
            Utile {review.likes > 0 && `(${review.likes})`}
          </button>
        </div>
      </div>
    </div>
  );
}

export function ReviewSection({ slug }: { slug: string }) {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [stats, setStats] = useState<ReviewStats>({ average: 0, count: 0, distribution: [0,0,0,0,0] });
  const [authorName, setAuthorName] = useState("");
  const [rating, setRating] = useState(0);
  const [content, setContent] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [myId] = useState(() => {
    try {
      let id = localStorage.getItem("heavenscans:uid");
      if (!id) { id = Math.random().toString(36).slice(2); localStorage.setItem("heavenscans:uid", id); }
      return id;
    } catch { return Math.random().toString(36).slice(2); }
  });
  const [showForm, setShowForm] = useState(false);
  const [showAll, setShowAll] = useState(false);
  const formRef = useRef<HTMLDivElement>(null);

  const reload = () => { const r = loadReviews(slug); setReviews(r); setStats(getReviewStats(slug)); };
  useEffect(() => { reload(); }, [slug]);

  const alreadyReviewed = reviews.some((r) => r.id.startsWith(myId));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!authorName.trim()) return setError("Entre ton pseudo.");
    if (rating === 0) return setError("Sélectionne une note.");
    if (content.trim().length < 10) return setError("Ton avis doit faire au moins 10 caractères.");
    const newReview: Review = {
      id: `${myId}-${Date.now()}`,
      author: authorName.trim(),
      rating,
      content: content.trim(),
      date: new Date().toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" }),
      likes: 0,
      likedByMe: false,
    };
    saveReviews(slug, [newReview, ...reviews]);
    reload();
    setContent(""); setRating(0); setSuccess(true); setShowForm(false);
    setTimeout(() => setSuccess(false), 3000);
  };

  const handleDelete = (id: string) => { saveReviews(slug, reviews.filter((r) => r.id !== id)); reload(); };
  const handleLike = (id: string) => {
    saveReviews(slug, reviews.map((r) => r.id === id ? { ...r, likes: r.likedByMe ? r.likes - 1 : r.likes + 1, likedByMe: !r.likedByMe } : r));
    reload();
  };

  const displayed = showAll ? reviews : reviews.slice(0, 3);

  return (
    <section className="mt-14">
      <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-2 text-primary text-sm font-semibold uppercase tracking-wider"><MessageSquare className="h-4 w-4" /> Avis de la communauté</div>
          <h2 className="mt-1 text-3xl font-black">Notes & Commentaires</h2>
        </div>
        {!alreadyReviewed && (
          <button onClick={() => { setShowForm((v) => !v); setTimeout(() => formRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" }), 100); }}
            className="inline-flex items-center gap-2 rounded-xl bg-[image:var(--gradient-hero)] px-5 py-2.5 text-sm font-bold text-white shadow-[var(--shadow-glow)] hover:scale-[1.02] transition">
            <Star className="h-4 w-4" /> Laisser un avis
          </button>
        )}
      </div>

      {stats.count > 0 && (
        <div className="mb-8 rounded-2xl border border-[color:var(--glass-border)] bg-[color:var(--glass-bg)] backdrop-blur-xl p-6 grid gap-6 sm:grid-cols-[auto_1fr]">
          <div className="flex flex-col items-center justify-center gap-1 sm:pr-6 sm:border-r sm:border-[color:var(--glass-border)]">
            <span className="text-6xl font-black bg-[image:var(--gradient-hero)] bg-clip-text text-transparent leading-none">{stats.average.toFixed(1)}</span>
            <StarPicker value={Math.round(stats.average)} size={18} readonly />
            <span className="text-xs text-muted-foreground mt-1">{stats.count} avis</span>
          </div>
          <div className="flex flex-col justify-center gap-2">
            {[5,4,3,2,1].map((star, i) => <RatingBar key={star} label={String(star)} count={stats.distribution[i]} total={stats.count} />)}
          </div>
        </div>
      )}

      {showForm && !alreadyReviewed && (
        <div ref={formRef} className="mb-8 rounded-2xl border border-[color:var(--glass-border)] bg-[color:var(--glass-bg)] backdrop-blur-xl p-6">
          <h3 className="font-black text-lg mb-5">Ton avis</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1.5">Pseudo</label>
              <input value={authorName} onChange={(e) => setAuthorName(e.target.value)} placeholder="Ton nom ou pseudo…" maxLength={40}
                className="w-full rounded-xl border border-border bg-background/60 px-4 py-2.5 text-sm outline-none focus:border-[color:var(--neon-blue)] focus:ring-1 focus:ring-[color:var(--neon-blue)]/30 transition placeholder:text-muted-foreground" />
            </div>
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2">Note</label>
              <StarPicker value={rating} onChange={setRating} size={28} />
            </div>
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1.5">Commentaire</label>
              <textarea value={content} onChange={(e) => setContent(e.target.value)} placeholder="Partage ton expérience avec cette série…" rows={4} maxLength={600}
                className="w-full rounded-xl border border-border bg-background/60 px-4 py-2.5 text-sm outline-none focus:border-[color:var(--neon-blue)] focus:ring-1 focus:ring-[color:var(--neon-blue)]/30 transition placeholder:text-muted-foreground resize-none" />
              <div className="text-right text-xs text-muted-foreground mt-1">{content.length}/600</div>
            </div>
            {error && <p className="text-sm text-destructive font-semibold rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2">{error}</p>}
            <div className="flex gap-3 justify-end">
              <button type="button" onClick={() => setShowForm(false)} className="rounded-xl border border-border px-4 py-2.5 text-sm font-bold hover:bg-muted transition">Annuler</button>
              <button type="submit" className="inline-flex items-center gap-2 rounded-xl bg-[image:var(--gradient-hero)] px-5 py-2.5 text-sm font-bold text-white shadow-[var(--shadow-glow)] hover:scale-[1.02] transition">
                <Send className="h-4 w-4" /> Publier
              </button>
            </div>
          </form>
        </div>
      )}

      {success && <div className="mb-6 rounded-xl border border-[oklch(0.70_0.18_160)/0.4] bg-[oklch(0.70_0.18_160)/0.12] px-4 py-3 text-sm font-semibold text-[oklch(0.70_0.18_160)]">✓ Ton avis a été publié !</div>}
      {alreadyReviewed && <div className="mb-6 rounded-xl border border-[color:var(--glass-border)] bg-[color:var(--glass-bg)] px-4 py-3 text-sm text-muted-foreground">Tu as déjà laissé un avis pour cette série. Retrouve-le ci-dessous.</div>}

      {reviews.length === 0 ? (
        <div className="rounded-2xl border border-[color:var(--glass-border)] bg-[color:var(--glass-bg)] backdrop-blur-xl p-10 text-center">
          <MessageSquare className="mx-auto h-10 w-10 text-muted-foreground opacity-40" />
          <p className="mt-3 font-semibold">Aucun avis pour l'instant</p>
          <p className="mt-1 text-sm text-muted-foreground">Sois le premier à donner ton avis sur cette série !</p>
          {!alreadyReviewed && (
            <button onClick={() => setShowForm(true)} className="mt-5 inline-flex items-center gap-2 rounded-xl border border-[color:var(--glass-border)] bg-background/40 px-5 py-2.5 text-sm font-bold hover:border-primary hover:text-primary transition">
              <Star className="h-4 w-4" /> Écrire un avis
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-3">
          {displayed.map((review) => (
            <ReviewCard key={review.id} review={review} isOwn={review.id.startsWith(myId)} onDelete={() => handleDelete(review.id)} onLike={() => handleLike(review.id)} />
          ))}
          {reviews.length > 3 && (
            <button onClick={() => setShowAll((v) => !v)} className="w-full rounded-xl border border-border py-3 text-sm font-semibold text-muted-foreground hover:text-foreground hover:border-primary transition-all inline-flex items-center justify-center gap-2">
              {showAll ? <><ChevronUp className="h-4 w-4" /> Voir moins</> : <><ChevronDown className="h-4 w-4" /> Voir les {reviews.length - 3} avis restants</>}
            </button>
          )}
        </div>
      )}
    </section>
  );
}
