import { Link } from "@tanstack/react-router";
import { Star, MessageSquare, Sparkles, Play } from "lucide-react";
import { useState, useEffect } from "react";
import type { Series } from "@/lib/series";
import { getReviewStats } from "@/components/ReviewSection";

export function SeriesCard({ s, index = 0 }: { s: Series; index?: number }) {
  const [communityRating, setCommunityRating] = useState<number | null>(null);
  const [reviewCount,     setReviewCount]     = useState(0);
  const [imgLoaded,       setImgLoaded]       = useState(false);

  useEffect(() => {
    const stats = getReviewStats(s.slug);
    if (stats.count > 0) { setCommunityRating(stats.average); setReviewCount(stats.count); }
  }, [s.slug]);

  const displayRating = communityRating ?? s.rating;
  const statusLabel   = s.status === "Ongoing" ? "En cours" : s.status === "Completed" ? "Terminé" : "Pause";
  const statusColor   = s.status === "Ongoing" ? "text-emerald-400" : s.status === "Completed" ? "text-sky-400" : "text-amber-400";

  const delay = index * 55;

  return (
    <Link
      to="/series/$slug"
      params={{ slug: s.slug }}
      className="card-3d group relative overflow-hidden rounded-xl bg-card reveal-scale"
      data-delay={String(delay)}
      style={{
        border: "1px solid oklch(0.20 0.018 265)",
        boxShadow: "0 8px 32px oklch(0 0 0 / 0.7)",
      }}
    >
      {/* Cover */}
      <div className="aspect-[2/3] overflow-hidden bg-muted relative">
        {!imgLoaded && <div className="absolute inset-0 animate-skeleton" />}
        <img src={s.cover} alt={s.title} loading="lazy" onLoad={() => setImgLoaded(true)}
          className={`h-full w-full object-cover transition-all duration-700 group-hover:scale-112 group-hover:brightness-40 ${imgLoaded ? "opacity-100" : "opacity-0"}`} />

        {/* Violet diagonal layer */}
        <div className="absolute inset-0 bg-[image:var(--grad-aurora)] opacity-0 group-hover:opacity-20 transition-opacity duration-500 [clip-path:polygon(0_50%,100%_20%,100%_100%,0_100%)]" />

        {/* Play */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 scale-50 group-hover:scale-100">
          <div className="relative grid h-11 w-11 place-items-center rounded-full bg-[image:var(--grad-violet)] shadow-[var(--glow-violet)]">
            <Play className="h-5 w-5 text-white fill-white translate-x-0.5" />
            <span className="absolute inset-0 rounded-full border border-[oklch(0.62_0.26_290/0.6)] animate-pulse-ring" />
            <span className="absolute inset-0 rounded-full border border-[oklch(0.62_0.26_290/0.3)] animate-pulse-ring d-300" />
          </div>
        </div>
      </div>

      {/* Type badge */}
      <div className="absolute top-2 left-2 rounded bg-[oklch(0.05_0.012_265/0.88)] backdrop-blur-sm px-2 py-0.5 text-[10px] font-black uppercase tracking-wider text-[oklch(0.72_0.18_290)] border border-[oklch(0.62_0.26_290/0.25)] animate-bounce-in"
        style={{ animationDelay: `${delay + 150}ms` }}>
        {s.type}
      </div>

      {/* New or rating */}
      {s.isNew ? (
        <div className="absolute top-2 right-2 flex items-center gap-0.5 rounded bg-[image:var(--grad-violet)] px-2 py-0.5 text-[10px] font-black uppercase tracking-wider text-white shadow-[var(--glow-violet)] animate-bounce-in"
          style={{ animationDelay: `${delay + 220}ms` }}>
          <Sparkles className="h-2.5 w-2.5" /> New
        </div>
      ) : displayRating != null ? (
        <div className="absolute top-2 right-2 flex items-center gap-1 rounded bg-[oklch(0.05_0.012_265/0.88)] backdrop-blur-sm px-2 py-0.5 text-xs font-bold border border-border">
          <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
          {displayRating.toFixed(1)}
          {reviewCount > 0 && <span className="text-muted-foreground text-[10px] flex items-center gap-0.5 ml-0.5"><MessageSquare className="h-2.5 w-2.5" />{reviewCount}</span>}
        </div>
      ) : null}

      {/* Info */}
      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-[oklch(0.04_0.012_265)] via-[oklch(0.04_0.012_265/0.92)] to-transparent p-3 pt-8">
        {/* Animated violet underline */}
        <div className="mb-1.5 h-[1.5px] w-4 rounded-full bg-[image:var(--grad-aurora)] group-hover:w-full transition-all duration-500 ease-out" />
        <h3 className="line-clamp-2 text-sm font-bold leading-tight">{s.title}</h3>
        <div className="mt-1 flex items-center justify-between">
          {s.chapters[0] ? <p className="text-[10px] text-muted-foreground">Ch. {s.chapters[0].number}</p> : <span />}
          <span className={`text-[10px] font-bold ${statusColor}`}>{statusLabel}</span>
        </div>
      </div>

      {/* Hover border glow */}
      <div className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-400 pointer-events-none"
        style={{ boxShadow: "inset 0 0 0 1px oklch(0.62 0.26 290 / 0.45), 0 0 40px oklch(0.62 0.26 290 / 0.2)" }} />
    </Link>
  );
}
