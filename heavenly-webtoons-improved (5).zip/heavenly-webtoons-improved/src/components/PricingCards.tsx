import { Check, Crown, Zap, Star } from "lucide-react";

const tiers = [
  {
    name: "Reader",
    price: "0",
    period: "Gratuit",
    icon: Star,
    features: ["Catalogue complet", "Lecture standard", "Support communauté"],
    cta: "Commencer gratuitement",
    highlight: false,
  },
  {
    name: "Premium",
    price: "4,99",
    period: "/ mois",
    icon: Crown,
    features: [
      "Accès anticipé aux chapitres",
      "Lecture sans publicité",
      "Chapitres exclusifs Premium",
      "Badge Premium sur Discord",
    ],
    cta: "Devenir Premium",
    highlight: true,
  },
  {
    name: "Ultimate",
    price: "9,99",
    period: "/ mois",
    icon: Zap,
    features: [
      "Tout le Premium",
      "Téléchargement hors-ligne",
      "Avant-premières exclusives",
      "Soutien direct à l'équipe",
    ],
    cta: "Passer Ultimate",
    highlight: false,
  },
];

export function PricingCards() {
  return (
    <div className="grid gap-6 md:grid-cols-3">
      {tiers.map((t) => {
        const Icon = t.icon;
        return (
          <div
            key={t.name}
            className={
              "group relative overflow-hidden rounded-2xl border p-7 transition-all duration-500 hover:-translate-y-2 " +
              (t.highlight
                ? "border-primary/40 bg-[oklch(0.10_0.012_260)] shadow-[var(--shadow-neon)]"
                : "border-border bg-card hover:border-primary/30 hover:shadow-[var(--shadow-glow)]")
            }
          >
            {/* Background glow */}
            <div className="pointer-events-none absolute -top-20 -right-20 h-52 w-52 rounded-full bg-[image:var(--gradient-hero)] opacity-0 blur-3xl transition-opacity duration-500 group-hover:opacity-15" />

            {t.highlight && (
              <>
                {/* Top crimson bar */}
                <div className="absolute top-0 left-0 right-0 h-0.5 bg-[image:var(--gradient-hero)]" />
                <div className="absolute top-4 right-4 rounded-full bg-[image:var(--gradient-hero)] px-2.5 py-0.5 text-[10px] font-black uppercase tracking-widest text-white shadow-[var(--shadow-glow)]">
                  ★ Populaire
                </div>
              </>
            )}

            {/* Icon */}
            <div className={
              "grid h-12 w-12 place-items-center rounded-xl transition-all duration-300 group-hover:scale-110 " +
              (t.highlight
                ? "bg-[image:var(--gradient-hero)] shadow-[var(--shadow-glow)]"
                : "border border-border bg-secondary group-hover:bg-[image:var(--gradient-hero)] group-hover:border-transparent group-hover:shadow-[var(--shadow-glow)]")
            }>
              <Icon className="h-5 w-5 text-white" />
            </div>

            <h3 className="mt-5 text-2xl font-black tracking-tight">{t.name}</h3>

            <div className="mt-1 flex items-baseline gap-1.5">
              <span className={
                "text-4xl font-black " +
                (t.highlight ? "bg-[image:var(--gradient-hero)] bg-clip-text text-transparent" : "")
              }>
                {t.price === "0" ? "Gratuit" : `${t.price}€`}
              </span>
              {t.price !== "0" && <span className="text-sm text-muted-foreground">{t.period}</span>}
            </div>

            {/* Divider */}
            <div className="my-5 h-px bg-gradient-to-r from-transparent via-border to-transparent" />

            <ul className="space-y-3 text-sm">
              {t.features.map((f) => (
                <li key={f} className="flex items-start gap-3">
                  <span className={
                    "mt-0.5 grid h-5 w-5 flex-none place-items-center rounded-full shrink-0 " +
                    (t.highlight ? "bg-[image:var(--gradient-hero)] shadow-[var(--shadow-glow)]" : "bg-secondary border border-border group-hover:bg-[image:var(--gradient-hero)] group-hover:border-transparent transition-all duration-300")
                  }>
                    <Check className="h-3 w-3 text-white" />
                  </span>
                  <span className="text-muted-foreground group-hover:text-foreground transition-colors duration-300">{f}</span>
                </li>
              ))}
            </ul>

            <button className={
              "mt-7 w-full rounded-xl py-3 text-sm font-black tracking-wide transition-all duration-300 " +
              (t.highlight
                ? "bg-[image:var(--gradient-hero)] text-white shadow-[var(--shadow-glow)] hover:shadow-[var(--shadow-neon)] hover:scale-[1.02]"
                : "border border-border bg-background/40 hover:border-primary hover:text-primary hover:bg-primary/5")
            }>
              {t.cta}
            </button>
          </div>
        );
      })}
    </div>
  );
}
