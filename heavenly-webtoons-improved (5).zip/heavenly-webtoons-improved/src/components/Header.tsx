import { Link } from "@tanstack/react-router";
import { Search, Menu, X, Clock, Trash2, Crown } from "lucide-react";
import { useState, useEffect, useRef, useMemo } from "react";
import { series, allGenres } from "@/lib/series";

const RECENT_KEY = "hs:searches";
const MAX_RECENT = 8;
type AppRoute = "/" | "/series" | "/genres" | "/latest" | "/premium";

const NAV: { to: AppRoute; label: string }[] = [
  { to: "/series",  label: "Séries" },
  { to: "/genres",  label: "Genres" },
  { to: "/latest",  label: "Sorties" },
];

export function Header() {
  const [open,        setOpen]        = useState(false);
  const [searchOpen,  setSearchOpen]  = useState(false);
  const [query,       setQuery]       = useState("");
  const [recent,      setRecent]      = useState<string[]>([]);
  const searchRef = useRef<HTMLDivElement>(null);
  const inputRef  = useRef<HTMLInputElement>(null);

  useEffect(() => {
    try { const r = localStorage.getItem(RECENT_KEY); if (r) setRecent(JSON.parse(r)); } catch {}
  }, []);

  const save = (arr: string[]) => { setRecent(arr); try { localStorage.setItem(RECENT_KEY, JSON.stringify(arr)); } catch {} };
  const addRecent    = (t: string) => { const s = t.trim(); if (!s) return; save([s, ...recent.filter(r => r.toLowerCase() !== s.toLowerCase())].slice(0, MAX_RECENT)); };
  const removeRecent = (t: string) => save(recent.filter(r => r !== t));

  const q = query.trim().toLowerCase();
  const { matchedSeries, matchedGenres } = useMemo(() => {
    if (!q) return { matchedSeries: [], matchedGenres: [] };
    return {
      matchedSeries: series.filter(s => s.title.toLowerCase().includes(q) || s.genres.some(g => g.toLowerCase().includes(q))).slice(0, 7),
      matchedGenres: allGenres.filter(g => g.toLowerCase().includes(q)).slice(0, 7),
    };
  }, [q]);

  useEffect(() => { if (searchOpen) inputRef.current?.focus(); }, [searchOpen]);
  useEffect(() => {
    const close = (e: MouseEvent) => { if (searchRef.current && !searchRef.current.contains(e.target as Node)) setSearchOpen(false); };
    const esc   = (e: KeyboardEvent) => { if (e.key === "Escape") setSearchOpen(false); };
    document.addEventListener("mousedown", close);
    document.addEventListener("keydown",   esc);
    return () => { document.removeEventListener("mousedown", close); document.removeEventListener("keydown", esc); };
  }, []);

  return (
    <header className="sticky top-0 z-50 bg-[oklch(0.055_0.012_265/0.88)] backdrop-blur-2xl border-b border-[oklch(0.20_0.018_265)]">
      {/* Aurora top line */}
      <div className="absolute top-0 left-0 right-0 h-[1.5px] bg-[image:var(--grad-aurora)] opacity-80" style={{ animation: "header-sweep 4s ease-in-out infinite" }} />

      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2.5 group flex-shrink-0">
          <img src="/logo.png" alt="HeavenScans"
            className="h-9 w-9 object-contain rounded-lg p-0.5 transition-all duration-300 group-hover:scale-110"
            style={{ filter: "drop-shadow(0 0 8px oklch(0.62 0.26 290 / 0.8)) drop-shadow(0 0 16px oklch(0.65 0.22 245 / 0.5))" }}
          />
          <span className="font-display text-lg font-bold tracking-wide text-gradient hidden sm:block">HeavenScans</span>
        </Link>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-6 text-[0.78rem] font-semibold tracking-widest uppercase">
          {NAV.map(({ to, label }) => (
            <Link key={to} to={to}
              className="text-muted-foreground hover:text-foreground transition-colors duration-200 hover-underline"
              activeProps={{ className: "text-foreground" }}>
              {label}
            </Link>
          ))}
          <Link to="/premium"
            className="btn-ripple inline-flex items-center gap-1.5 rounded-lg border border-[oklch(0.62_0.26_290/0.35)] bg-[oklch(0.62_0.26_290/0.10)] px-3.5 py-1.5 text-[oklch(0.75_0.18_290)] hover:border-[oklch(0.62_0.26_290/0.7)] hover:bg-[oklch(0.62_0.26_290/0.18)] hover:shadow-[var(--glow-violet)] transition-all duration-300">
            <Crown className="h-3.5 w-3.5" /> Premium
          </Link>
        </nav>

        {/* Search + burger */}
        <div className="flex items-center gap-2" ref={searchRef}>
          <div className="relative">
            <button onClick={() => setSearchOpen(v => !v)} aria-label="Rechercher"
              className="grid h-9 w-9 place-items-center rounded-lg border border-border bg-secondary hover:border-[oklch(0.62_0.26_290/0.5)] hover:text-[oklch(0.72_0.18_290)] transition-all duration-200">
              <Search className="h-4 w-4" />
            </button>

            {searchOpen && (
              <div className="absolute right-0 top-12 w-[min(90vw,420px)] rounded-xl border border-border bg-[oklch(0.09_0.014_265)] shadow-[var(--glow-card)] overflow-hidden animate-slide-up">
                <div className="absolute top-0 left-0 right-0 h-[1px] bg-[image:var(--grad-aurora)]" />
                <div className="flex items-center gap-2 border-b border-border px-3">
                  <Search className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                  <input ref={inputRef} value={query} onChange={e => setQuery(e.target.value)}
                    placeholder="Série, genre…"
                    className="flex-1 bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground" />
                  {query && <button onClick={() => setQuery("")} className="text-muted-foreground hover:text-primary transition-colors"><X className="h-4 w-4" /></button>}
                </div>
                <div className="max-h-[60vh] overflow-y-auto">
                  {!q && recent.length === 0 && <div className="p-8 text-center text-sm text-muted-foreground">Tape pour chercher dans le catalogue.</div>}
                  {!q && recent.length > 0 && (
                    <div className="py-2">
                      <div className="flex items-center justify-between px-4 py-1.5">
                        <span className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-muted-foreground"><Clock className="h-3 w-3" /> Récentes</span>
                        <button onClick={() => save([])} className="text-[10px] font-semibold text-muted-foreground hover:text-primary transition-colors flex items-center gap-1"><Trash2 className="h-3 w-3" /> Effacer</button>
                      </div>
                      {recent.map(term => (
                        <div key={term} className="group/r flex items-center gap-2 px-4 py-2 hover:bg-muted/60 transition-colors">
                          <Clock className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
                          <button onClick={() => { setQuery(term); inputRef.current?.focus(); }} className="flex-1 text-left text-sm truncate hover:text-primary transition-colors">{term}</button>
                          <button onClick={() => removeRecent(term)} className="opacity-0 group-hover/r:opacity-100 text-muted-foreground hover:text-primary transition-all"><X className="h-3.5 w-3.5" /></button>
                        </div>
                      ))}
                    </div>
                  )}
                  {q && matchedSeries.length === 0 && matchedGenres.length === 0 && <div className="p-8 text-center text-sm text-muted-foreground">Aucun résultat pour « {query} ».</div>}
                  {matchedSeries.length > 0 && (
                    <div className="py-2">
                      <div className="px-4 py-1.5 text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Séries</div>
                      {matchedSeries.map(s => (
                        <Link key={s.slug} to="/series/$slug" params={{ slug: s.slug }} onClick={() => { addRecent(s.title); setSearchOpen(false); setQuery(""); }}
                          className="flex items-center gap-3 px-4 py-2.5 hover:bg-muted/60 transition-colors group/item">
                          <div className="h-12 w-9 flex-shrink-0 overflow-hidden rounded-lg bg-muted ring-1 ring-border group-hover/item:ring-[oklch(0.62_0.26_290/0.5)] transition-all">
                            <img src={s.cover} alt={s.title} className="h-full w-full object-cover" />
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="truncate text-sm font-bold group-hover/item:text-primary transition-colors">{s.title}</div>
                            <div className="text-xs text-muted-foreground mt-0.5">{s.type} · {s.chapters.length} ch.</div>
                          </div>
                        </Link>
                      ))}
                    </div>
                  )}
                  {matchedGenres.length > 0 && (
                    <div className="border-t border-border py-3 px-4">
                      <div className="pb-2 text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Genres</div>
                      <div className="flex flex-wrap gap-2">
                        {matchedGenres.map(g => (
                          <Link key={g} to="/genres" onClick={() => { addRecent(g); setSearchOpen(false); setQuery(""); }}
                            className="rounded-full border border-border bg-secondary px-3 py-1 text-xs font-semibold hover:border-primary hover:text-primary transition-all">
                            {g}
                          </Link>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          <button onClick={() => setOpen(!open)} className="md:hidden grid h-9 w-9 place-items-center rounded-lg border border-border bg-secondary hover:border-primary/40 transition-all" aria-label="Menu">
            {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {open && (
        <nav className="md:hidden border-t border-border bg-[oklch(0.07_0.014_265/0.97)] backdrop-blur-xl px-4 py-3 flex flex-col gap-1 animate-slide-up">
          {NAV.map(({ to, label }) => (
            <Link key={to} to={to} onClick={() => setOpen(false)}
              className="rounded-lg px-3 py-2.5 font-semibold text-muted-foreground hover:text-foreground hover:bg-muted transition-all text-sm tracking-wide">
              {label}
            </Link>
          ))}
          <Link to="/premium" onClick={() => setOpen(false)}
            className="mt-2 rounded-lg border border-[oklch(0.62_0.26_290/0.35)] bg-[oklch(0.62_0.26_290/0.10)] px-3 py-2.5 font-bold text-[oklch(0.72_0.18_290)] inline-flex items-center gap-2 hover:bg-[oklch(0.62_0.26_290/0.18)] transition-all text-sm">
            <Crown className="h-4 w-4" /> Premium
          </Link>
        </nav>
      )}
    </header>
  );
}
