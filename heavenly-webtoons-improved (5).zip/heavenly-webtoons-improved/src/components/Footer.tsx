import { Link } from "@tanstack/react-router";
import { MessageCircle, Twitter, Github, Heart, Crown } from "lucide-react";

type AppRoute = "/" | "/series" | "/genres" | "/latest" | "/premium";
const NAV: { to: AppRoute; label: string }[] = [
  { to: "/",        label: "Accueil" },
  { to: "/series",  label: "Séries" },
  { to: "/genres",  label: "Genres" },
  { to: "/latest",  label: "Sorties" },
  { to: "/premium", label: "Premium" },
];
const INFO = [
  { label: "À propos",           href: "#" },
  { label: "Discord",            href: "https://discord.gg/" },
  { label: "Contact",            href: "mailto:contact@heavenscans.fr" },
  { label: "DMCA / Signalement", href: "#" },
  { label: "CGU",                href: "#" },
];

export function Footer() {
  return (
    <footer className="mt-24 border-t border-border bg-[oklch(0.07_0.014_265)]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-14 grid gap-10 md:grid-cols-4">
        {/* Brand */}
        <div className="md:col-span-2">
          <div className="flex items-center gap-2.5 mb-4">
            <img src="/logo.png" alt="HeavenScans"
              className="h-10 w-10 object-contain rounded-lg p-0.5"
              style={{ filter: "drop-shadow(0 0 10px oklch(0.62 0.26 290 / 0.7)) drop-shadow(0 0 20px oklch(0.65 0.22 245 / 0.4))" }}
            />
            <span className="font-display text-xl font-bold text-gradient tracking-wide">HeavenScans</span>
          </div>
          <p className="text-sm text-muted-foreground leading-relaxed max-w-sm">
            Votre portail céleste vers les meilleurs mangas, manhwas, manhuas et webtoons traduits par une équipe passionnée.
          </p>
          <Link to="/premium"
            className="mt-5 inline-flex items-center gap-2 rounded-xl border border-[oklch(0.62_0.26_290/0.35)] bg-[oklch(0.62_0.26_290/0.08)] px-4 py-2.5 text-sm font-bold text-[oklch(0.72_0.18_290)] hover:bg-[oklch(0.62_0.26_290/0.16)] hover:border-[oklch(0.62_0.26_290/0.6)] hover:shadow-[var(--glow-violet)] transition-all duration-300">
            <Crown className="h-4 w-4" /> Devenir Premium
          </Link>
          <div className="mt-5 flex gap-2">
            {[
              { Icon: Twitter,       href: "https://twitter.com/", label: "Twitter" },
              { Icon: MessageCircle, href: "https://discord.gg/",  label: "Discord" },
              { Icon: Github,        href: "https://github.com/",  label: "GitHub"  },
            ].map(({ Icon, href, label }) => (
              <a key={label} href={href} target="_blank" rel="noopener noreferrer" aria-label={label}
                className="grid h-9 w-9 place-items-center rounded-lg border border-border bg-secondary hover:border-[oklch(0.62_0.26_290/0.5)] hover:text-[oklch(0.72_0.18_290)] transition-all duration-200">
                <Icon className="h-4 w-4" />
              </a>
            ))}
          </div>
        </div>

        <div>
          <h4 className="text-[10px] font-black uppercase tracking-[0.18em] text-muted-foreground mb-4">Navigation</h4>
          <ul className="space-y-2.5 text-sm">
            {NAV.map(({ to, label }) => (
              <li key={to}><Link to={to} className="text-muted-foreground hover:text-primary hover-underline transition-colors duration-200">{label}</Link></li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="text-[10px] font-black uppercase tracking-[0.18em] text-muted-foreground mb-4">Infos</h4>
          <ul className="space-y-2.5 text-sm">
            {INFO.map(({ label, href }) => (
              <li key={label}><a href={href} className="text-muted-foreground hover:text-foreground transition-colors">{label}</a></li>
            ))}
          </ul>
        </div>
      </div>

      <div className="relative border-t border-border py-5 text-center text-xs text-muted-foreground">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 h-px w-32 bg-[image:var(--grad-aurora)] opacity-70" />
        <span>© {new Date().getFullYear()} HeavenScans.</span>
        <span className="inline-flex items-center gap-1 ml-2">Fait avec <Heart className="h-3 w-3 fill-[oklch(0.62_0.26_290)] text-[oklch(0.62_0.26_290)]" /> par la team.</span>
      </div>
    </footer>
  );
}
