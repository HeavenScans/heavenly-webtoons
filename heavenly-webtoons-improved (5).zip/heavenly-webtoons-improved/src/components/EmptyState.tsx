import { BookOpen } from "lucide-react";

export function EmptyState({
  title = "Aucune série pour le moment",
  hint = "Les nouvelles sorties apparaîtront ici dès leur ajout.",
}: {
  title?: string;
  hint?: string;
}) {
  return (
    <div className="relative flex flex-col items-center justify-center overflow-hidden rounded-2xl border border-dashed border-border bg-card/40 px-6 py-20 text-center">
      <div className="absolute inset-0 -z-10 [background:radial-gradient(circle_at_50%_50%,oklch(0.62_0.23_22/0.08),transparent_70%)]" />
      <div className="relative grid h-16 w-16 place-items-center rounded-2xl bg-[image:var(--gradient-hero)] shadow-[var(--shadow-glow)]">
        <BookOpen className="h-7 w-7 text-white" />
        <div className="absolute -inset-1 rounded-2xl bg-[image:var(--gradient-hero)] opacity-30 blur-lg -z-10" />
      </div>
      <h3 className="mt-5 text-lg font-black tracking-tight">{title}</h3>
      <p className="mt-2 max-w-sm text-sm text-muted-foreground">{hint}</p>
    </div>
  );
}
