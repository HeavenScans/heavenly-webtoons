import { useEffect, useRef } from "react";

/**
 * useReveal — attaches an IntersectionObserver to all .reveal / .reveal-left /
 * .reveal-right / .reveal-scale elements inside the given container (default: document).
 * Adds the "visible" class when an element enters the viewport.
 */
export function useReveal(containerRef?: React.RefObject<HTMLElement | null>) {
  useEffect(() => {
    const root = containerRef?.current ?? document;
    const targets = root.querySelectorAll<HTMLElement>(
      ".reveal, .reveal-left, .reveal-right, .reveal-scale"
    );

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const el = entry.target as HTMLElement;
            const delay = el.dataset.delay ? parseInt(el.dataset.delay) : 0;
            setTimeout(() => el.classList.add("visible"), delay);
            observer.unobserve(el);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
    );

    targets.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);
}

/**
 * useMagneticCards — adds subtle mouse-tracking 3D tilt to .card-magnetic elements.
 */
export function useMagneticCards(containerRef?: React.RefObject<HTMLElement | null>) {
  useEffect(() => {
    const root = containerRef?.current ?? document;
    const cards = root.querySelectorAll<HTMLElement>(".card-magnetic");

    const handleMove = (e: MouseEvent) => {
      const card = e.currentTarget as HTMLElement;
      const rect = card.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width  - 0.5;
      const y = (e.clientY - rect.top)  / rect.height - 0.5;
      card.style.transform = `perspective(600px) rotateY(${x * 10}deg) rotateX(${-y * 10}deg) translateY(-6px) scale(1.02)`;
      card.style.boxShadow = `${-x * 12}px ${-y * 12}px 40px oklch(0.62 0.23 22 / 0.35)`;
    };
    const handleLeave = (e: MouseEvent) => {
      const card = e.currentTarget as HTMLElement;
      card.style.transform = "";
      card.style.boxShadow = "";
    };

    cards.forEach((card) => {
      card.addEventListener("mousemove", handleMove);
      card.addEventListener("mouseleave", handleLeave);
    });
    return () => {
      cards.forEach((card) => {
        card.removeEventListener("mousemove", handleMove);
        card.removeEventListener("mouseleave", handleLeave);
      });
    };
  }, []);
}
