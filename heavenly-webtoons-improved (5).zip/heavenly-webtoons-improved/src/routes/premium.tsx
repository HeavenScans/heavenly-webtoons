import { createFileRoute } from "@tanstack/react-router";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { PricingCards } from "@/components/PricingCards";
import { Crown, Zap, ShieldOff, BookOpen, MessageCircle, Star, Check } from "lucide-react";

export const Route = createFileRoute("/premium")({
  head: () => ({
    meta: [
      { title: "Premium — HeavenScans" },
      { name: "description", content: "Devenez membre Premium et accédez aux chapitres en avant-première sans publicité." },
    ],
  }),
  component: PremiumPage,
});

const PERKS = [
  { Icon: Zap,          label: "Accès anticipé",       desc: "Lis les chapitres 48h avant tout le monde." },
  { Icon: ShieldOff,    label: "Zéro publicité",        desc: "Lecture immersive, sans interruption." },
  { Icon: BookOpen,     label: "Chapitres exclusifs",   desc: "Du contenu réservé aux membres Premium." },
  { Icon: MessageCircle,label: "Badge Discord",         desc: "Un rôle exclusif sur notre serveur." },
  { Icon: Star,         label: "Vote sur les scans",    desc: "Influence le choix des prochaines séries." },
  { Icon: Crown,        label: "Soutien à l'équipe",    desc: "Tu finances directement nos traducteurs." },
];

function PremiumPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      {/* Hero */}
      <section className="relative overflow-hidden border-b border-border">
        <div className="absolute inset-0 -z-10 [background:radial-gradient(ellipse_70%_60%_at_50%_0%,oklch(0.62_0.23_22/0.18),transparent)]" />
        <div className="absolute top-0 left-0 right-0 h-[2px] bg-[image:var(--gradient-hero)]" />

        <div className="mx-auto max-w-4xl px-4 sm:px-6 py-20 sm:py-28 text-center">
          <div className="mx-auto animate-glow-pulse">
            <img
              src="/logo.png"
              alt="HeavenScans Premium"
              className="h-28 w-28 object-contain drop-shadow-[0_0_40px_oklch(0.65_0.25_295/0.8)]"
            />
          </div>
          <h1 className="mt-7 text-5xl sm:text-6xl font-black tracking-tight">
            Heaven<span className="bg-[image:var(--gradient-hero)] bg-clip-text text-transparent">Premium</span>
          </h1>
          <p className="mt-4 max-w-lg mx-auto text-base text-muted-foreground leading-relaxed">
            Rejoins des milliers de lecteurs qui soutiennent HeavenScans et profitent d'une expérience sans limite.
          </p>
        </div>
      </section>

      <main className="mx-auto w-full max-w-6xl flex-1 px-4 sm:px-6 py-16 space-y-20">

        {/* Perks grid */}
        <section>
          <div className="text-center mb-10">
            <div className="text-xs font-black uppercase tracking-widest text-primary mb-2">Avantages</div>
            <h2 className="text-3xl font-black">Ce que tu obtiens</h2>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {PERKS.map(({ Icon, label, desc }) => (
              <div key={label} className="group relative overflow-hidden rounded-xl border border-border bg-card p-5 hover:border-primary/40 hover:shadow-[var(--shadow-glow)] transition-all duration-300 hover:-translate-y-1">
                <div className="absolute inset-0 -z-10 [background:radial-gradient(circle_at_0%_0%,oklch(0.62_0.23_22/0.06),transparent_60%)] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                <div className="grid h-10 w-10 place-items-center rounded-xl bg-[image:var(--gradient-hero)] shadow-[var(--shadow-glow)] mb-4 transition-transform duration-300 group-hover:scale-110">
                  <Icon className="h-5 w-5 text-white" />
                </div>
                <h3 className="font-black tracking-tight group-hover:text-primary transition-colors">{label}</h3>
                <p className="mt-1.5 text-sm text-muted-foreground">{desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Pricing */}
        <section>
          <div className="text-center mb-10">
            <div className="text-xs font-black uppercase tracking-widest text-primary mb-2">Tarifs</div>
            <h2 className="text-3xl font-black">Choisir ton plan</h2>
            <p className="mt-2 text-sm text-muted-foreground">Sans engagement. Annulable à tout moment.</p>
          </div>
          <PricingCards />
        </section>

        {/* FAQ teaser */}
        <section className="rounded-2xl border border-border bg-card p-8 sm:p-10">
          <div className="absolute top-0 left-0 right-0" />
          <h2 className="text-2xl font-black mb-6">Questions fréquentes</h2>
          <div className="grid gap-4 sm:grid-cols-2">
            {[
              { q: "Comment annuler mon abonnement ?", a: "Depuis ton espace membre, section « Abonnement »." },
              { q: "L'accès Premium est-il immédiat ?", a: "Oui, dès la confirmation du paiement." },
              { q: "Puis-je partager mon compte ?", a: "Non, chaque compte est personnel et intransférable." },
              { q: "Quels moyens de paiement ?", a: "Carte bancaire, PayPal et crypto acceptés." },
            ].map(({ q, a }) => (
              <div key={q} className="group rounded-xl border border-border bg-background/60 p-4 hover:border-primary/30 transition-colors">
                <div className="flex items-start gap-3">
                  <Check className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-bold group-hover:text-primary transition-colors">{q}</p>
                    <p className="mt-1 text-xs text-muted-foreground">{a}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

      </main>
      <Footer />
    </div>
  );
}
