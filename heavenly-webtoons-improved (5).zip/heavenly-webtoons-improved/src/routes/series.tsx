import { createFileRoute } from "@tanstack/react-router";
import { useRef } from "react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { SeriesCard } from "@/components/SeriesCard";
import { EmptyState } from "@/components/EmptyState";
import { series } from "@/lib/series";
import { useState, useMemo, useEffect } from "react";
import { SlidersHorizontal, X } from "lucide-react";
import { useReveal, useMagneticCards } from "@/hooks/useAnimations";

export const Route = createFileRoute("/series")({
  head: () => ({
    meta: [
      { title: "Séries — HeavenScans" },
      { name: "description", content: "Catalogue complet des mangas, manhwas et webtoons traduits par HeavenScans." },
    ],
  }),
  component: SeriesPage,
});

const TYPES    = ["Tous", "Manga", "Manhwa", "Manhua", "Webtoon"] as const;
const STATUSES = ["Tous", "En cours", "Terminé", "En pause"] as const;
const STATUS_MAP: Record<string, string> = { "En cours": "Ongoing", "Terminé": "Completed", "En pause": "Hiatus" };
const SORTS    = ["A–Z", "Z–A", "Note", "Plus récent"] as const;

function SeriesPage() {
  const pageRef = useRef<HTMLDivElement>(null);
  useReveal(pageRef as any);
  useMagneticCards(pageRef as any);

  const [typeFilter,   setTypeFilter]   = useState("Tous");
  const [statusFilter, setStatusFilter] = useState("Tous");
  const [sort,         setSort]         = useState<typeof SORTS[number]>("Plus récent");
  const [showFilters,  setShowFilters]  = useState(false);

  const filtered = useMemo(() => {
    let list = [...series];
    if (typeFilter !== "Tous")   list = list.filter((s) => s.type === typeFilter);
    if (statusFilter !== "Tous") list = list.filter((s) => s.status === STATUS_MAP[statusFilter]);
    switch (sort) {
      case "A–Z":         list.sort((a, b) => a.title.localeCompare(b.title)); break;
      case "Z–A":         list.sort((a, b) => b.title.localeCompare(a.title)); break;
      case "Note":        list.sort((a, b) => (b.rating ?? 0) - (a.rating ?? 0)); break;
      case "Plus récent": list.sort((a, b) => (b.chapters[0]?.releasedAt ?? "").localeCompare(a.chapters[0]?.releasedAt ?? "")); break;
    }
    return list;
  }, [typeFilter, statusFilter, sort]);

  const hasFilters = typeFilter !== "Tous" || statusFilter !== "Tous";

  return (
    <div ref={pageRef as any} className="min-h-screen flex flex-col">
      <Header />
      <main className="mx-auto w-full max-w-7xl flex-1 px-4 sm:px-6 py-12">
        <div className="flex flex-wrap items-end justify-between gap-4 mb-6 reveal">
          <div>
            <p className="text-xs font-black uppercase tracking-widest text-primary">Bibliothèque</p>
            <h1 className="mt-1 text-4xl font-black">Toutes les séries</h1>
            <p className="mt-1 text-muted-foreground">{filtered.length} série{filtered.length > 1 ? "s" : ""}</p>
          </div>
          <button onClick={() => setShowFilters((v) => !v)}
            className={`btn-ripple inline-flex items-center gap-2 rounded-xl border px-4 py-2.5 text-sm font-semibold transition-all duration-300 ${showFilters ? "border-primary bg-primary/10 text-primary shadow-[var(--shadow-glow)]" : "border-border hover:border-primary/50 hover:text-primary"}`}>
            <SlidersHorizontal className="h-4 w-4" /> Filtres {hasFilters && <span className="h-2 w-2 rounded-full bg-primary animate-pulse-ring" />}
          </button>
        </div>

        {/* Filter panel — slide down */}
        <div className={`overflow-hidden transition-all duration-400 ease-out ${showFilters ? "max-h-96 opacity-100 mb-6" : "max-h-0 opacity-0"}`}>
          <div className="rounded-2xl border border-border bg-card/60 backdrop-blur-xl p-5 space-y-4">
            <div className="grid sm:grid-cols-3 gap-4">
              {[
                { label: "Type", items: TYPES, value: typeFilter, set: setTypeFilter },
                { label: "Statut", items: STATUSES, value: statusFilter, set: setStatusFilter },
                { label: "Trier par", items: SORTS, value: sort, set: setSort as any },
              ].map(({ label, items, value, set }) => (
                <div key={label}>
                  <label className="text-xs font-black uppercase tracking-wider text-muted-foreground mb-2 block">{label}</label>
                  <div className="flex flex-wrap gap-2">
                    {(items as readonly string[]).map((item) => (
                      <button key={item} onClick={() => set(item)}
                        className={`rounded-full border px-3 py-1 text-xs font-semibold transition-all duration-200 ${value === item ? "border-primary bg-primary/10 text-primary shadow-[var(--shadow-glow)]" : "border-border text-muted-foreground hover:border-primary/50 hover:text-foreground"}`}>
                        {item}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            {hasFilters && (
              <button onClick={() => { setTypeFilter("Tous"); setStatusFilter("Tous"); }}
                className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-primary transition-colors">
                <X className="h-3.5 w-3.5" /> Réinitialiser
              </button>
            )}
          </div>
        </div>

        {filtered.length === 0 ? (
          <EmptyState title="Aucune série trouvée" hint="Modifie les filtres pour voir plus de séries." />
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {filtered.map((s, i) => <SeriesCard key={s.slug} s={s} index={i} />)}
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}
