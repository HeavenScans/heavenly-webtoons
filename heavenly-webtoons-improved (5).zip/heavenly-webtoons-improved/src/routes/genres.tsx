import { createFileRoute, Link } from "@tanstack/react-router";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { SeriesCard } from "@/components/SeriesCard";
import { allGenres, series } from "@/lib/series";
import { useState } from "react";
import { Tag, X } from "lucide-react";

export const Route = createFileRoute("/genres")({
  head: () => ({
    meta: [
      { title: "Genres — HeavenScans" },
      { name: "description", content: "Parcourez les séries par genre sur HeavenScans." },
    ],
  }),
  component: GenresPage,
});

const GENRE_ICONS: Record<string, string> = {
  "Action": "⚔️", "Aventure": "🗺️", "Comédie": "😄", "Drame": "🎭",
  "Fantastique": "✨", "Horreur": "🩸", "Isekai": "🌀", "Romance": "💕",
  "Sci-Fi": "🚀", "Shonen": "🔥", "Seinen": "🎯", "Slice of Life": "🌸",
  "Surnaturel": "👻", "Thriller": "🔍",
};

function GenresPage() {
  const [selected, setSelected] = useState<string | null>(null);

  const filtered = selected ? series.filter((s) => s.genres.includes(selected)) : [];

  const toggle = (g: string) => setSelected((prev) => (prev === g ? null : g));

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="mx-auto w-full max-w-7xl flex-1 px-4 sm:px-6 py-12">
        <div className="mb-8">
          <div className="flex items-center gap-2 text-primary text-sm font-semibold uppercase tracking-wider">
            <Tag className="h-4 w-4" /> Catégories
          </div>
          <h1 className="mt-1 text-4xl font-black">Tous les genres</h1>
          <p className="mt-2 text-muted-foreground">Clique sur un genre pour filtrer les séries.</p>
        </div>

        {/* Genre grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-3 mb-12">
          {allGenres.map((g) => {
            const count = series.filter((s) => s.genres.includes(g)).length;
            const isActive = selected === g;
            return (
              <button
                key={g}
                onClick={() => toggle(g)}
                className={`group rounded-xl border p-4 text-left transition-all duration-200 hover:-translate-y-0.5 ${
                  isActive
                    ? "border-primary bg-primary/10 shadow-[var(--shadow-glow)]"
                    : "border-border bg-card hover:border-primary/60 hover:bg-card/80"
                }`}
              >
                <div className="text-2xl mb-2">{GENRE_ICONS[g] ?? "📚"}</div>
                <div className={`text-sm font-bold transition-colors ${isActive ? "text-primary" : "group-hover:text-primary"}`}>{g}</div>
                <div className="mt-0.5 text-xs text-muted-foreground">{count} série{count > 1 ? "s" : ""}</div>
              </button>
            );
          })}
        </div>

        {/* Results */}
        {selected && (
          <section>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-black flex items-center gap-2">
                <span>{GENRE_ICONS[selected]}</span> {selected}
                <span className="text-lg font-normal text-muted-foreground">({filtered.length} série{filtered.length > 1 ? "s" : ""})</span>
              </h2>
              <button onClick={() => setSelected(null)} className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-sm text-muted-foreground hover:text-foreground hover:border-primary transition">
                <X className="h-3.5 w-3.5" /> Effacer
              </button>
            </div>
            {filtered.length === 0 ? (
              <div className="text-center py-16 text-muted-foreground">Aucune série dans ce genre pour l'instant.</div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {filtered.map((s) => <SeriesCard key={s.slug} s={s} />)}
              </div>
            )}
          </section>
        )}
      </main>
      <Footer />
    </div>
  );
}
