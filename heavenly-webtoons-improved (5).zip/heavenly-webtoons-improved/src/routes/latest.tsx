import { createFileRoute } from "@tanstack/react-router";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { series } from "@/lib/series";
import { Link } from "@tanstack/react-router";
import { Clock, Flame, Filter, Crown } from "lucide-react";
import { PremiumBadge } from "@/components/PremiumLock";
import { useState, useMemo } from "react";

export const Route = createFileRoute("/latest")({
  head: () => ({
    meta: [
      { title: "Derniers chapitres — HeavenScans" },
      { name: "description", content: "Tous les derniers chapitres publiés sur HeavenScans." },
    ],
  }),
  component: LatestPage,
});

const TYPES = ["Tous", "Manga", "Manhwa", "Manhua", "Webtoon"] as const;

function formatDate(dateStr: string): string {
  try {
    const d = new Date(dateStr);
    const now = new Date();
    const diff = Math.floor((now.getTime() - d.getTime()) / 86400000);
    if (diff === 0) return "Aujourd'hui";
    if (diff === 1) return "Hier";
    if (diff < 7) return `Il y a ${diff} jours`;
    return d.toLocaleDateString("fr-FR", { day: "numeric", month: "short" });
  } catch { return dateStr; }
}

function LatestPage() {
  const [typeFilter, setTypeFilter] = useState<string>("Tous");

  const items = useMemo(() => {
    const all = series
      .filter((s) => typeFilter === "Tous" || s.type === typeFilter)
      .flatMap((s) => s.chapters.slice(0, 3).map((c) => ({ s, c })));

    // Sort by date descending
    return all.sort((a, b) => {
      try { return new Date(b.c.releasedAt).getTime() - new Date(a.c.releasedAt).getTime(); }
      catch { return 0; }
    });
  }, [typeFilter]);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="mx-auto w-full max-w-4xl flex-1 px-4 sm:px-6 py-12">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-2 text-primary text-sm font-semibold uppercase tracking-wider">
            <Flame className="h-4 w-4" /> Mises à jour
          </div>
          <h1 className="mt-1 text-4xl font-black">Derniers chapitres</h1>
          <p className="mt-2 text-muted-foreground">{items.length} publication{items.length > 1 ? "s" : ""} récente{items.length > 1 ? "s" : ""}.</p>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-2 mb-6 flex-wrap">
          <Filter className="h-4 w-4 text-muted-foreground flex-shrink-0" />
          {TYPES.map((t) => (
            <button
              key={t}
              onClick={() => setTypeFilter(t)}
              className={`rounded-full border px-4 py-1.5 text-sm font-semibold transition-all ${
                typeFilter === t
                  ? "border-primary bg-primary/10 text-primary shadow-[var(--shadow-glow)]"
                  : "border-border text-muted-foreground hover:border-primary/50 hover:text-foreground"
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        {/* List */}
        {items.length === 0 ? (
          <div className="text-center py-20 text-muted-foreground">Aucun chapitre dans cette catégorie.</div>
        ) : (
          <ul className="divide-y divide-[color:var(--glass-border)] rounded-2xl border border-[color:var(--glass-border)] bg-[color:var(--glass-bg)] backdrop-blur-xl overflow-hidden">
            {items.map(({ s, c }, i) => (
              <li key={i}>
                <Link to="/series/$slug" params={{ slug: s.slug }}
                  className="group flex items-center gap-4 p-4 hover:bg-muted/40 transition-all hover:translate-x-1">
                  <img src={s.cover} alt={s.title} className="h-16 w-12 rounded-lg object-cover bg-muted flex-shrink-0 shadow-md" />
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="font-bold truncate group-hover:text-primary transition-colors">{s.title}</h3>
                      {s.premium && <PremiumBadge />}
                      <span className="rounded bg-secondary/60 px-1.5 py-0.5 text-[10px] font-semibold uppercase text-muted-foreground">{s.type}</span>
                    </div>
                    <p className="text-sm text-muted-foreground mt-0.5">
                      Chapitre {c.number}{c.title ? ` — ${c.title}` : ""}
                    </p>
                  </div>
                  <div className="text-xs text-muted-foreground flex-shrink-0 inline-flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {formatDate(c.releasedAt)}
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </main>
      <Footer />
    </div>
  );
}
