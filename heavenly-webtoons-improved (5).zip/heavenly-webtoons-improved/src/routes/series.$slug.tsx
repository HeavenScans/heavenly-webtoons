import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useRef } from "react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { series } from "@/lib/series";
import { Star, BookOpen, Clock, Lock, Eye, TrendingUp } from "lucide-react";
import { PremiumLock, PremiumBadge, ComingSoon } from "@/components/PremiumLock";
import { ReviewSection, getReviewStats } from "@/components/ReviewSection";
import { useReveal } from "@/hooks/useAnimations";

export const Route = createFileRoute("/series/$slug")({
  component: SeriesDetail,
  notFoundComponent: () => (
    <div className="min-h-screen grid place-items-center bg-background text-foreground">
      <div className="text-center animate-slide-up">
        <h1 className="text-4xl font-black">Série introuvable</h1>
        <Link to="/series" className="mt-4 inline-block text-primary">← Retour au catalogue</Link>
      </div>
    </div>
  ),
});

function formatViews(n?: number) {
  if (!n) return null;
  return n >= 1000 ? `${(n / 1000).toFixed(0)}k vues` : `${n} vues`;
}

function SeriesDetail() {
  const pageRef = useRef<HTMLDivElement>(null);
  useReveal(pageRef as React.RefObject<HTMLElement>);

  const { slug } = Route.useParams();
  const s = series.find((x) => x.slug === slug);
  if (!s) throw notFound();

  const communityStats = getReviewStats(slug);
  const displayRating  = communityStats.count > 0 ? communityStats.average : s.rating;
  const displayCount   = communityStats.count;

  const statusLabel = s.status === "Ongoing" ? "En cours" : s.status === "Completed" ? "Terminé" : "En pause";
  const statusColor = s.status === "Ongoing"
    ? "text-emerald-400 bg-emerald-400/10 border-emerald-400/20"
    : s.status === "Completed"
    ? "text-sky-400 bg-sky-400/10 border-sky-400/20"
    : "text-amber-400 bg-amber-400/10 border-amber-400/20";

  return (
    <div ref={pageRef as any} className="min-h-screen flex flex-col">
      <Header />

      {/* Hero */}
      <div className="relative overflow-hidden border-b border-border">
        <div className="absolute inset-0 -z-10 opacity-20 scale-110"
          style={{ backgroundImage: `url(${s.cover})`, backgroundSize: "cover", backgroundPosition: "center", filter: "blur(60px)" }} />
        <div className="absolute inset-0 -z-10 bg-background/88" />
        <div className="absolute inset-0 -z-10 [background:radial-gradient(ellipse_60%_80%_at_0%_50%,oklch(0.62_0.23_22/0.10),transparent)]" />

        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-12 grid gap-8 md:grid-cols-[220px_1fr]">
          {/* Cover */}
          <div className="relative w-full max-w-[220px] animate-slide-up">
            <img src={s.cover} alt={s.title} className="w-full rounded-2xl shadow-[var(--shadow-neon)] ring-1 ring-primary/20 transition-transform duration-500 hover:scale-[1.02] hover:shadow-[0_0_60px_oklch(0.62_0.23_22/0.5)]" />
            {s.isNew && (
              <div className="absolute top-3 left-3 rounded-lg bg-[image:var(--gradient-hero)] px-2.5 py-1 text-[10px] font-black uppercase tracking-wider text-white shadow-[var(--shadow-glow)] animate-bounce-in">
                ✦ Nouveau
              </div>
            )}
          </div>

          {/* Info */}
          <div className="animate-slide-up delay-75">
            <div className="flex flex-wrap items-center gap-2 text-xs font-bold uppercase tracking-wider">
              <span className="rounded-lg bg-primary/15 border border-primary/20 px-2.5 py-1 text-primary">{s.type}</span>
              <span className={`rounded-lg border px-2.5 py-1 ${statusColor}`}>{statusLabel}</span>
              {displayRating != null && (
                <span className="inline-flex items-center gap-1 rounded-lg bg-secondary border border-border px-2.5 py-1">
                  <Star className="h-3 w-3 fill-[oklch(0.75_0.19_55)] text-[oklch(0.75_0.19_55)]" />
                  {displayRating.toFixed(1)}
                  {displayCount > 0 && <span className="text-muted-foreground font-normal">({displayCount} avis)</span>}
                </span>
              )}
              {s.views && (
                <span className="inline-flex items-center gap-1 rounded-lg bg-secondary border border-border px-2.5 py-1 text-muted-foreground">
                  <Eye className="h-3 w-3" /> {formatViews(s.views)}
                </span>
              )}
            </div>

            <h1 className="mt-4 text-4xl sm:text-5xl font-black leading-tight tracking-tight">{s.title}</h1>

            <div className="mt-3 flex flex-wrap gap-2">
              {s.genres.map((g) => (
                <Link key={g} to="/genres"
                  className="rounded-full border border-border bg-card/50 px-3 py-1 text-xs font-medium hover:border-primary hover:text-primary hover:bg-primary/8 transition-all duration-200">
                  {g}
                </Link>
              ))}
            </div>

            <p className="mt-5 max-w-3xl text-muted-foreground leading-relaxed">{s.synopsis}</p>

            <div className="mt-5 flex flex-wrap gap-3 text-sm text-muted-foreground">
              <span className="inline-flex items-center gap-1"><TrendingUp className="h-3.5 w-3.5" /> {s.chapters.length} chapitre{s.chapters.length > 1 ? "s" : ""}</span>
            </div>
          </div>
        </div>
      </div>

      <main className="mx-auto w-full max-w-7xl flex-1 px-4 sm:px-6 py-12">
        <h2 className="text-2xl font-black mb-4 inline-flex items-center gap-2 reveal">
          <BookOpen className="h-5 w-5 text-primary" /> Chapitres
        </h2>

        {s.chapters.length === 0 ? (
          <div className="space-y-6 reveal">
            <PremiumLock cover={s.cover} />
            <ComingSoon />
          </div>
        ) : (
          <ul className="divide-y divide-border rounded-2xl border border-border bg-card/40 backdrop-blur-xl overflow-hidden reveal">
            {s.chapters.map((c, i) => (
              <li key={c.number}
                className="group flex items-center justify-between p-4 hover:bg-muted/50 hover:pl-6 transition-all duration-300 ease-out"
                style={{ transitionDelay: `${i * 20}ms` }}>
                <div className="flex items-center gap-3">
                  <div className="grid h-9 w-9 place-items-center rounded-lg border border-border bg-background/40 text-primary group-hover:bg-[image:var(--gradient-hero)] group-hover:text-white group-hover:border-transparent group-hover:shadow-[var(--shadow-glow)] transition-all duration-300">
                    <Lock className="h-4 w-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <div className="font-semibold group-hover:text-primary transition-colors">Chapitre {c.number}</div>
                      {s.premium && <PremiumBadge />}
                    </div>
                    {c.title && <div className="text-sm text-muted-foreground">{c.title}</div>}
                  </div>
                </div>
                <div className="text-xs text-muted-foreground flex-shrink-0 inline-flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  {new Date(c.releasedAt).toLocaleDateString("fr-FR", { day: "numeric", month: "short", year: "numeric" })}
                </div>
              </li>
            ))}
          </ul>
        )}

        <ReviewSection slug={slug} />
      </main>
      <Footer />
    </div>
  );
}

// Need React import for useRef type
import React from "react";
