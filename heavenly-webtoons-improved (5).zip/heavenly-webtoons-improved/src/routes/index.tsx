import React, { useRef } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { SeriesCard } from "@/components/SeriesCard";
import { EmptyState } from "@/components/EmptyState";
import { ParticleCanvas } from "@/components/ParticleCanvas";
import { useReveal, useMagneticCards } from "@/hooks/useAnimations";
import { series, allGenres } from "@/lib/series";
import {
  Flame, Sparkles, TrendingUp, ArrowRight, Crown,
  Zap, ShieldOff, BookOpen, Star, ChevronRight,
} from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "HeavenScans — Mangas, Manhwas & Webtoons en VF" },
      { name: "description", content: "Lisez les derniers chapitres de mangas, manhwas, manhuas et webtoons traduits par HeavenScans." },
      { property: "og:image", content: "/logo.png" },
    ],
  }),
  component: Index,
});

type AppRoute = "/" | "/series" | "/genres" | "/latest" | "/premium";

function SectionHeader({ eyebrow, icon: Icon, title, href }: { eyebrow: string; icon: React.ElementType; title: string; href: AppRoute }) {
  return (
    <div className="flex items-end justify-between gap-4 mb-7 reveal">
      <div>
        <div className="flex items-center gap-2 text-[0.68rem] font-black uppercase tracking-[0.18em] text-[oklch(0.62_0.26_290)] mb-1">
          <span className="h-px w-5 bg-[oklch(0.62_0.26_290)]" />
          <Icon className="h-3.5 w-3.5" /> {eyebrow}
        </div>
        <h2 className="font-display text-2xl sm:text-3xl font-bold text-gradient">{title}</h2>
      </div>
      <Link to={href} className="shrink-0 inline-flex items-center gap-1 text-xs font-bold text-muted-foreground hover:text-[oklch(0.72_0.18_290)] transition-colors hover-underline group">
        Voir tout <ChevronRight className="h-3.5 w-3.5 group-hover:translate-x-0.5 transition-transform" />
      </Link>
    </div>
  );
}

function Index() {
  const pageRef = useRef<HTMLDivElement>(null);
  useReveal(pageRef as React.RefObject<HTMLElement>);
  useMagneticCards(pageRef as React.RefObject<HTMLElement>);

  const latest       = [...series].sort((a, b) => (b.chapters[0]?.releasedAt ?? "").localeCompare(a.chapters[0]?.releasedAt ?? "")).slice(0, 12);
  const popular      = [...series].sort((a, b) => (b.views ?? 0) - (a.views ?? 0)).slice(0, 6);
  const topRated     = [...series].filter(s => s.rating != null).sort((a, b) => (b.rating ?? 0) - (a.rating ?? 0)).slice(0, 6);
  const totalChapters = series.reduce((sum, s) => sum + s.chapters.length, 0);

  return (
    <div ref={pageRef} className="min-h-screen flex flex-col">
      <Header />

      {/* ══ HERO ══ */}
      <section className="relative overflow-hidden min-h-[88vh] flex items-center border-b border-border">
        {/* Starfield + deep bg */}
        <div className="absolute inset-0 -z-30 bg-[oklch(0.055_0.012_265)]" />
        {/* Aurora radial */}
        <div className="absolute inset-0 -z-20 [background:radial-gradient(ellipse_80%_70%_at_50%_-10%,oklch(0.62_0.26_290/0.18),transparent),radial-gradient(ellipse_50%_50%_at_85%_40%,oklch(0.65_0.22_245/0.12),transparent),radial-gradient(ellipse_40%_60%_at_15%_80%,oklch(0.55_0.24_280/0.08),transparent)]" />
        {/* Grid */}
        <div className="absolute inset-0 -z-10 opacity-[0.03] [background-image:linear-gradient(oklch(0.75_0.18_290)_1px,transparent_1px),linear-gradient(90deg,oklch(0.75_0.18_290)_1px,transparent_1px)] [background-size:60px_60px] [mask-image:radial-gradient(ellipse_at_center,black_20%,transparent_75%)]" />
        {/* Particles */}
        <ParticleCanvas className="-z-10" />
        {/* Floating covers */}
        <div className="absolute inset-0 -z-10 overflow-hidden pointer-events-none select-none">
          {series.slice(0, 8).map((s, i) => (
            <img key={s.slug} src={s.cover} alt="" loading="lazy"
              className="absolute object-cover rounded-2xl opacity-[0.06]"
              style={{
                width: `${90 + (i % 3) * 28}px`,
                height: `${135 + (i % 3) * 42}px`,
                top: `${4 + (i % 4) * 22}%`,
                left: `${2 + i * 12}%`,
                transform: `rotate(${-9 + i * 2.5}deg)`,
                filter: "blur(2px)",
                animation: `logo-float ${5 + i * 0.6}s ease-in-out ${i * 0.5}s infinite`,
              }} />
          ))}
        </div>
        {/* Beam */}
        <div className="absolute inset-y-0 left-0 w-full overflow-hidden pointer-events-none -z-10">
          <div className="absolute inset-y-0 w-1/3 bg-[image:var(--grad-aurora)] opacity-0 [animation:beam_6s_ease-in-out_2s_infinite]" style={{ filter: "blur(1px)" }} />
        </div>

        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-24 sm:py-32 relative w-full">
          <div className="grid md:grid-cols-[1fr_auto] gap-12 items-center">
            {/* Left */}
            <div>
              {/* Badge */}
              <div className="inline-flex items-center gap-2 rounded-full border border-[oklch(0.62_0.26_290/0.35)] bg-[oklch(0.62_0.26_290/0.08)] px-4 py-1.5 text-[0.68rem] font-black uppercase tracking-[0.15em] text-[oklch(0.72_0.18_290)] animate-slide-up d-0 mb-5">
                <span className="h-1.5 w-1.5 rounded-full bg-[oklch(0.62_0.26_290)] shadow-[0_0_8px_oklch(0.62_0.26_290)]" style={{ animation: "dot-blink 2s ease-in-out infinite" }} />
                Bienvenue dans le paradis du scan
              </div>

              {/* Title */}
              <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-black tracking-tight leading-[1.03] animate-slide-up d-60 mb-5">
                <span className="block text-foreground">Lis les meilleurs</span>
                <span className="block text-gradient animate-neon">Mangas & Webtoons</span>
              </h1>

              <p className="text-base sm:text-lg text-muted-foreground leading-relaxed max-w-lg animate-slide-up d-120 mb-8">
                Mangas, manhwas, manhuas et webtoons traduits par une équipe passionnée. Nouvelles sorties chaque semaine.
              </p>

              {/* CTAs */}
              <div className="flex flex-wrap gap-3 animate-slide-up d-180 mb-12">
                <Link to="/series"
                  className="btn-ripple inline-flex items-center gap-2 rounded-xl bg-[image:var(--grad-violet)] px-7 py-3.5 text-sm font-black text-white shadow-[var(--glow-violet)] hover:shadow-[0_0_60px_oklch(0.62_0.26_290/0.7),0_0_100px_oklch(0.65_0.22_245/0.4)] hover:scale-[1.03] transition-all duration-300">
                  Explorer les séries <ArrowRight className="h-4 w-4" />
                </Link>
                <Link to="/latest"
                  className="btn-ripple inline-flex items-center gap-2 rounded-xl border border-[oklch(0.62_0.26_290/0.35)] bg-[oklch(0.62_0.26_290/0.06)] px-7 py-3.5 text-sm font-bold text-[oklch(0.72_0.18_290)] hover:border-[oklch(0.62_0.26_290/0.7)] hover:bg-[oklch(0.62_0.26_290/0.12)] transition-all duration-300">
                  Derniers chapitres
                </Link>
              </div>

              {/* Stats */}
              <div className="flex flex-wrap gap-4 animate-slide-up d-240">
                {[{ v: `${series.length}`, l: "Séries" }, { v: `${totalChapters}+`, l: "Chapitres" }, { v: `${allGenres.length}`, l: "Genres" }].map(({ v, l }, i) => (
                  <div key={l} className="flex items-center gap-3 rounded-xl border border-border bg-card/50 backdrop-blur px-5 py-3 hover:border-[oklch(0.62_0.26_290/0.5)] hover:shadow-[var(--glow-violet)] transition-all duration-300 cursor-default group">
                    <span className="font-display text-2xl font-bold text-gradient" style={{ animationDelay: `${450 + i * 80}ms` }}>{v}</span>
                    <span className="text-xs text-muted-foreground group-hover:text-foreground transition-colors">{l}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Right — Logo showcase */}
            <div className="hidden md:flex items-center justify-center animate-slide-up d-120">
              <div className="relative w-72 h-72 flex items-center justify-center">
                {/* Outer orbit ring */}
                <div className="absolute w-64 h-64 rounded-full border border-[oklch(0.62_0.26_290/0.20)]" style={{ animation: "orbit-cw 16s linear infinite" }}>
                  <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-[oklch(0.62_0.26_290)] shadow-[0_0_14px_oklch(0.62_0.26_290)]" />
                </div>
                {/* Inner orbit ring */}
                <div className="absolute w-44 h-44 rounded-full border border-[oklch(0.65_0.22_245/0.18)]" style={{ animation: "orbit-ccw 10s linear infinite" }}>
                  <div className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-[oklch(0.65_0.22_245)] shadow-[0_0_10px_oklch(0.65_0.22_245)]" />
                </div>
                {/* Glow bg */}
                <div className="absolute w-48 h-48 rounded-full bg-[radial-gradient(circle,oklch(0.62_0.26_290/0.18),transparent_70%)] blur-2xl" />
                {/* Logo */}
                <img src="/logo.png" alt="HeavenScans"
                  className="relative z-10 w-36 h-36 object-contain animate-logo-float animate-logo-glow" />
              </div>
            </div>
          </div>
        </div>

        <div className="absolute bottom-0 left-0 right-0 h-28 bg-gradient-to-t from-background to-transparent pointer-events-none" />
      </section>

      {/* ══ MAIN ══ */}
      <main className="mx-auto w-full max-w-7xl flex-1 px-4 sm:px-6 py-16 space-y-20">

        {/* Latest */}
        <section>
          <SectionHeader eyebrow="Mises à jour" icon={Flame} title="Fraîchement traduits" href="/latest" />
          {latest.length === 0 ? <EmptyState /> : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {latest.map((s, i) => <SeriesCard key={s.slug} s={s} index={i} />)}
            </div>
          )}
        </section>

        {/* Popular */}
        <section>
          <SectionHeader eyebrow="Tendances" icon={TrendingUp} title="Populaire cette semaine" href="/series" />
          {popular.length === 0 ? <EmptyState title="Le top arrive bientôt" hint="Ajoute tes premières séries." /> : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
              {popular.map((s, i) => <SeriesCard key={s.slug} s={s} index={i} />)}
            </div>
          )}
        </section>

        {/* Top rated */}
        <section>
          <SectionHeader eyebrow="Meilleurs scores" icon={Star} title="Les mieux notés" href="/series" />
          {topRated.length === 0 ? <EmptyState /> : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
              {topRated.map((s, i) => <SeriesCard key={s.slug} s={s} index={i} />)}
            </div>
          )}
        </section>

        {/* Genre marquee */}
        <section>
          <div className="mb-6 reveal">
            <div className="text-[0.68rem] font-black uppercase tracking-[0.18em] text-muted-foreground">Parcourir</div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-gradient mt-1">Par genre</h2>
          </div>
          <div className="relative overflow-hidden -mx-4 sm:-mx-6 reveal">
            <div className="flex gap-3 animate-marquee w-max px-4 sm:px-6 py-2">
              {[...allGenres, ...allGenres].map((g, i) => (
                <Link key={i} to="/genres"
                  className="shrink-0 rounded-xl border border-border bg-card px-5 py-2.5 text-sm font-semibold whitespace-nowrap hover:border-[oklch(0.62_0.26_290/0.6)] hover:text-[oklch(0.72_0.18_290)] hover:bg-[oklch(0.62_0.26_290/0.06)] hover:shadow-[var(--glow-violet)] transition-all duration-200">
                  {g}
                </Link>
              ))}
            </div>
            <div className="absolute inset-y-0 left-0 w-16 bg-gradient-to-r from-background to-transparent pointer-events-none" />
            <div className="absolute inset-y-0 right-0 w-16 bg-gradient-to-l from-background to-transparent pointer-events-none" />
          </div>
        </section>

        {/* Premium teaser */}
        <section className="relative overflow-hidden rounded-2xl border border-[oklch(0.62_0.26_290/0.25)] bg-[oklch(0.08_0.014_265)] p-8 sm:p-12 reveal">
          <div className="absolute top-0 left-0 right-0 h-[2px] bg-[image:var(--grad-aurora)]" style={{ animation: "header-sweep 3s ease-in-out infinite" }} />
          <div className="absolute inset-0 -z-10 [background:radial-gradient(ellipse_70%_80%_at_0%_50%,oklch(0.62_0.26_290/0.12),transparent),radial-gradient(ellipse_50%_60%_at_100%_50%,oklch(0.65_0.22_245/0.10),transparent)]" />
          <div className="grid gap-8 md:grid-cols-[1.2fr_1fr] items-center">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full border border-[oklch(0.62_0.26_290/0.35)] bg-[oklch(0.62_0.26_290/0.08)] px-3 py-1 text-[0.68rem] font-black uppercase tracking-[0.15em] text-[oklch(0.72_0.18_290)] mb-4">
                <Crown className="h-3 w-3" /> HeavenScans Premium
              </div>
              <h2 className="font-display text-3xl sm:text-4xl font-black leading-tight mb-3">
                Lecture <span className="text-gradient">sans limite</span>,<br className="hidden sm:block" /> sans pub.
              </h2>
              <p className="text-sm text-muted-foreground leading-relaxed max-w-md mb-6">Accès anticipé, chapitres exclusifs et soutien direct à l'équipe de traduction.</p>
              <div className="flex flex-wrap gap-3">
                <Link to="/premium"
                  className="btn-ripple inline-flex items-center gap-2 rounded-xl bg-[image:var(--grad-violet)] px-5 py-3 text-sm font-black text-white shadow-[var(--glow-violet)] hover:shadow-[0_0_60px_oklch(0.62_0.26_290/0.7)] hover:scale-[1.02] transition-all duration-300">
                  <Crown className="h-4 w-4" /> Devenir Premium
                </Link>
                <Link to="/premium" className="inline-flex items-center gap-2 rounded-xl border border-border bg-background/40 px-5 py-3 text-sm font-bold hover:border-[oklch(0.62_0.26_290/0.5)] hover:text-[oklch(0.72_0.18_290)] transition-all duration-300">
                  Voir les avantages
                </Link>
              </div>
            </div>
            <ul className="grid gap-3">
              {[
                { Icon: Zap,       l: "Accès anticipé aux chapitres" },
                { Icon: ShieldOff, l: "Lecture sans publicité" },
                { Icon: BookOpen,  l: "Chapitres exclusifs Premium" },
              ].map(({ Icon, l }, i) => (
                <li key={l} className="flex items-center gap-3 rounded-xl border border-border bg-background/40 px-4 py-3.5 hover:border-[oklch(0.62_0.26_290/0.45)] hover:translate-x-1.5 hover:shadow-[var(--glow-violet)] transition-all duration-300 group cursor-default reveal-right" data-delay={String(i * 100)}>
                  <span className="grid h-9 w-9 place-items-center rounded-lg bg-[image:var(--grad-violet)] shadow-[var(--glow-violet)] shrink-0 group-hover:scale-110 transition-transform duration-300">
                    <Icon className="h-4 w-4 text-white" />
                  </span>
                  <span className="text-sm font-semibold group-hover:text-[oklch(0.72_0.18_290)] transition-colors">{l}</span>
                </li>
              ))}
            </ul>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
