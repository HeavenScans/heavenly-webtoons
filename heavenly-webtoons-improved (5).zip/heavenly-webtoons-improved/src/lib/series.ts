// ═══════════════════════════════════════════════════════════
// HEAVENSCANS — Catalogue vide
// Ajoutez vos séries ici en suivant le format ci-dessous.
// ═══════════════════════════════════════════════════════════

export type Chapter = {
  number: string;
  title?: string;
  releasedAt: string;   // format "YYYY-MM-DD"
};

export type Series = {
  slug: string;         // URL : /series/mon-slug
  title: string;
  cover: string;        // chemin vers public/ ex: /covers/ma-serie.jpg
  type: "Manga" | "Manhwa" | "Manhua" | "Webtoon" | "Webcomic";
  status: "Ongoing" | "Completed" | "Hiatus";
  genres: string[];
  rating?: number;      // note sur 5 (optionnel)
  synopsis: string;
  chapters: Chapter[];
  premium?: boolean;    // accès réservé aux membres Premium
  isNew?: boolean;      // badge "New" affiché sur la card
  views?: number;       // nombre de vues pour le classement
};

// ── Ajoutez vos séries ici ───────────────────────────────
export const series: Series[] = [

  // Exemple à copier/coller et remplir :
  // {
  //   slug: "nom-de-la-serie",
  //   title: "Nom de la Série",
  //   cover: "/covers/nom-de-la-serie.jpg",
  //   type: "Manhwa",
  //   status: "Ongoing",
  //   genres: ["Action", "Fantastique"],
  //   rating: 4.5,
  //   synopsis: "Description de la série...",
  //   views: 10000,
  //   isNew: true,
  //   premium: false,
  //   chapters: [
  //     { number: "1", title: "Titre du chapitre", releasedAt: "2025-05-17" },
  //   ],
  // },

];

// ── Genres disponibles ───────────────────────────────────
export const allGenres = [
  "Action",
  "Aventure",
  "Comédie",
  "Drame",
  "Fantastique",
  "Horreur",
  "Isekai",
  "Romance",
  "Sci-Fi",
  "Shonen",
  "Seinen",
  "Slice of Life",
  "Surnaturel",
  "Thriller",
];
